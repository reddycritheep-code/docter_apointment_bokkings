import { ShieldAlert } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import type { AppRole } from "@shared/carebook";

export default function RoleGate({ role, children }: { role: AppRole; children: React.ReactNode }) {
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  if (auth.loading || (auth.user && account.isLoading)) return <div className="page-wrap"><div className="loading-card" role="status">Loading your secure workspace…</div></div>;
  if (!auth.user) return <div className="page-wrap"><div className="empty-state"><span className="empty-icon"><ShieldAlert size={22} /></span><h1>Sign in to continue</h1><p>Carebook uses your authenticated account to protect appointment details.</p><button className="button button-primary" onClick={() => startLogin()}>Sign in securely <span>↗</span></button></div></div>;
  if (account.data?.role !== role) {
    const setup = account.data?.role ? null : <Link className="button button-primary" href={role === "doctor" ? "/register/doctor" : "/register/patient"}>Set up your {role} profile <span>↗</span></Link>;
    return <div className="page-wrap"><div className="empty-state"><span className="empty-icon"><ShieldAlert size={22} /></span><h1>This area is for {role}s</h1><p>Your account does not currently have the required role. Each account can only access its own role-specific features.</p>{setup}</div></div>;
  }
  return <>{children}</>;
}
