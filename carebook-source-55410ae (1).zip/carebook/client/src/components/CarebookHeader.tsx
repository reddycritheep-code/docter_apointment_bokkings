import { Bell, ChevronDown, Leaf, LogOut, Menu, ShieldCheck, UserRound } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

export default function CarebookHeader() {
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const role = account.data?.role;
  const dashboard = role === "admin" ? "/admin/dashboard" : role === "doctor" ? "/doctor/dashboard" : role === "patient" ? "/patient/dashboard" : "/register/patient";

  return <header className="site-header">
    <div className="header-inner">
      <Link href="/" className="brand" aria-label="Carebook home">
        <span className="brand-mark"><Leaf size={18} strokeWidth={2.3} /><span className="brand-cross">+</span></span>
        <span>carebook</span>
      </Link>
      <nav className={`top-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
        <Link className={location === "/find-doctor" ? "nav-active" : ""} href="/find-doctor" onClick={() => setMenuOpen(false)}>Find a doctor</Link>
        <a href="/#how-it-works" onClick={() => setMenuOpen(false)}>How it works</a>
        <Link href="/register/doctor" onClick={() => setMenuOpen(false)}>For doctors</Link>
      </nav>
      <div className="header-actions">
        {auth.user ? <>
          <Link className="icon-button notification-link" href={dashboard} aria-label="Open your dashboard"><Bell size={18} /><span className="sr-only">Dashboard notifications</span></Link>
          <div className="account-menu">
            <button className="account-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen}>
              <span className="avatar-small">{(auth.user.name || "U").charAt(0).toUpperCase()}</span>
              <span className="account-name">{auth.user.name?.split(" ")[0] || "Account"}</span><ChevronDown size={14} />
            </button>
            {menuOpen && <div className="account-popover">
              <Link href={dashboard} onClick={() => setMenuOpen(false)}>{role === "admin" ? <ShieldCheck size={15} /> : <UserRound size={15} />} {role ? `${role[0].toUpperCase()}${role.slice(1)} dashboard` : "Set up your profile"}</Link>
              <button onClick={() => { setMenuOpen(false); void auth.logout(); }}><LogOut size={15} /> Sign out</button>
            </div>}
          </div>
        </> : <button className="button button-small button-outline" onClick={() => startLogin()}>Sign in <span className="button-arrow">↗</span></button>}
        <button className="mobile-menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" aria-expanded={menuOpen}><Menu size={20} /></button>
      </div>
    </div>
  </header>;
}
