import { ArrowUpRight, MapPin, Video, Wallet } from "lucide-react";
import { Link } from "wouter";
import type { PublicDoctorSummary } from "@shared/carebook";

const avatarColors = ["sage", "lavender", "peach", "blue"];
const initials = (name: string) => name.replace("Dr. ", "").split(/\s+/).map(part => part[0]).slice(0, 2).join("").toUpperCase();

export default function DoctorCard({ doctor, index = 0 }: { doctor: PublicDoctorSummary; index?: number }) {
  return <article className="doctor-card">
    <div className="doctor-card-top">
      <div className={`doctor-avatar avatar-${avatarColors[index % avatarColors.length]}`} aria-hidden="true"><span>{initials(doctor.name)}</span><i className="avatar-sparkle">✳</i></div>
      <div className="doctor-card-title">
        <span className="specialty-label">{doctor.specialty}</span>
        <h3>{doctor.name}</h3>
        <p className="credentials">{doctor.qualifications} <span>·</span> {doctor.experienceYears} years</p>
      </div>
      <span className="verified-pill" title="Profile reviewed"><span className="verified-dot">✓</span> Verified</span>
    </div>
    <p className="doctor-bio">{doctor.bio}</p>
    <div className="doctor-card-meta">
      <span><MapPin size={15} />{doctor.location}</span>
      <span><Wallet size={15} />${doctor.fee} / visit</span>
      <span><Video size={15} />{doctor.consultationTypes.includes("online") ? "In-person & online" : "In-person"}</span>
    </div>
    <div className="doctor-card-bottom">
      <div className="language-line">Speaks {doctor.languages.join(", ")}</div>
      <Link href={`/doctors/${doctor.slug}`} className="text-link">View profile <ArrowUpRight size={16} /></Link>
    </div>
  </article>;
}
