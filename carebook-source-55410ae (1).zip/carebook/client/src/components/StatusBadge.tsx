import type { AppointmentStatus } from "@shared/carebook";

const labels: Record<AppointmentStatus, string> = { pending: "Pending", approved: "Approved", rejected: "Rejected", cancelled: "Cancelled" };
export function StatusBadge({ status }: { status: AppointmentStatus }) {
  return <span className={`status-badge status-${status}`}><span className="status-dot" aria-hidden="true" />{labels[status]}</span>;
}

export function formatSlot(slot: string) {
  const value = new Date(`${slot}:00Z`);
  return new Intl.DateTimeFormat("en-US", { timeZone: "UTC", weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(value);
}
