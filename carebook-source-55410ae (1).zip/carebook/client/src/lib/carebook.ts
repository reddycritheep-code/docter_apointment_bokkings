import { formatClinicDate, formatClinicSlot, formatClinicTime } from "@shared/timezone";

export { formatClinicDate, formatClinicSlot, formatClinicTime };

export function dateInputValue(offset = 0) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

/** Legacy display for a clinic-local wall-time string before UTC snapshots were added. */
export function displayLocalSlot(value: string) {
  const date = new Date(`${value}:00Z`);
  return new Intl.DateTimeFormat("en-US", { timeZone: "UTC", weekday: "long", month: "long", day: "numeric", hour: "numeric", minute: "2-digit" }).format(date);
}

export function initials(name?: string | null) {
  return (name || "Carebook").replace(/^Dr\.\s*/, "").split(/\s+/).map(piece => piece[0]).slice(0, 2).join("").toUpperCase();
}

export function getDashboardHref(role?: string | null) {
  if (role === "admin") return "/admin/dashboard";
  if (role === "doctor") return "/doctor/dashboard";
  if (role === "patient") return "/patient/dashboard";
  return "/register/patient";
}
