import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import DoctorProfile from "./pages/DoctorProfile";
import PatientDashboard from "./pages/PatientDashboard";
import DoctorDashboard from "./pages/DoctorDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import AppointmentDetail from "./pages/AppointmentDetail";
import Login from "./pages/Login";
import { DoctorRegistration, PatientRegistration } from "./pages/Registration";
import { Route, Switch } from "wouter";
import "./carebook.css";

function NotFound() {
  return <main className="page-wrap"><div className="empty-state"><span className="section-kicker">404 · Not found</span><h1>We couldn't find that page.</h1><p>Let's get you back to finding the care you need.</p><a href="/" className="button button-primary">Back to Carebook</a></div></main>;
}

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/find-doctor" component={Home} />
    <Route path="/doctors/:slug" component={DoctorProfile} />
    <Route path="/login" component={Login} />
    <Route path="/register/patient" component={PatientRegistration} />
    <Route path="/register/doctor" component={DoctorRegistration} />
    <Route path="/patient/dashboard" component={PatientDashboard} />
    <Route path="/doctor/dashboard" component={DoctorDashboard} />
    <Route path="/admin/dashboard" component={AdminDashboard} />
    <Route path="/appointments/:id" component={AppointmentDetail} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
