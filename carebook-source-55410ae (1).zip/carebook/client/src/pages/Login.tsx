import { ArrowLeft, ArrowRight, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import CarebookHeader from "@/components/CarebookHeader";
import { getDashboardHref } from "@/lib/carebook";
import { trpc } from "@/lib/trpc";

export default function Login() {
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  if (auth.user && account.data?.role) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="form-page-card"><span className="form-symbol"><ShieldCheck size={24} /></span><span className="section-kicker">You're signed in</span><h1>Good to see you, {auth.user.name?.split(" ")[0] || "there"}.</h1><p>Your account is ready. Continue to your Carebook workspace.</p><Link href={getDashboardHref(account.data.role)} className="button button-primary">Open your dashboard <ArrowRight size={17} /></Link></div></main></div>;
  return <div className="site-page"><CarebookHeader /><main className="page-wrap login-wrap"><Link href="/" className="back-link"><ArrowLeft size={16} /> Back to Carebook</Link><div className="form-page-card"><span className="form-symbol"><Sparkles size={23} /></span><span className="section-kicker">A secure place for your care</span><h1>Sign in to Carebook.</h1><p>Use your Manus account to keep your profile and appointment details protected. We never display a pretend signed-in user.</p><button className="button button-primary button-wide" onClick={() => startLogin()}>Continue with Manus <ArrowRight size={17} /></button><div className="secure-note"><ShieldCheck size={16} /><span>Your contact details and appointment notes stay tied to your authenticated account.</span></div><div className="login-divider"><span>New to Carebook?</span></div><div className="login-role-links"><Link href="/register/patient">Set up as a patient <ArrowRight size={15} /></Link><Link href="/register/doctor">Join as a doctor <ArrowRight size={15} /></Link></div></div></main></div>;
}
