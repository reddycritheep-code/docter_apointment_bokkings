import { ArrowDown, ArrowRight, ArrowUpRight, CalendarDays, Check, Clock3, HeartPulse, MapPin, Search, ShieldCheck, Sparkles, Video } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import CarebookHeader from "@/components/CarebookHeader";
import DoctorCard from "@/components/DoctorCard";
import { dateInputValue } from "@/lib/carebook";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const [specialty, setSpecialty] = useState("");
  const [location, setLocation] = useState("");
  const [consultationType, setConsultationType] = useState("");
  const [availableDate, setAvailableDate] = useState("");
  const [searchSubmitted, setSearchSubmitted] = useState(false);
  const specialties = trpc.doctors.specialties.useQuery();
  const filters = useMemo(() => ({ specialty: specialty || undefined, location: location.trim() || undefined, consultationType: (consultationType || undefined) as "in_person" | "online" | undefined, availableDate: availableDate || undefined }), [specialty, location, consultationType, availableDate]);
  const doctors = trpc.doctors.list.useQuery(filters);
  const isSearch = window.location.pathname === "/find-doctor" || searchSubmitted || Boolean(specialty || location || consultationType || availableDate);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    setSearchSubmitted(true);
    document.getElementById("doctor-results")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return <div className="site-page">
    <CarebookHeader />
    <main>
      <section className="hero section-shell">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> A more human way to book care</div>
          <h1>Care that fits<br /><em>your day.</em></h1>
          <p className="hero-lede">Find the right doctor, choose a time that works, and take one small step toward feeling better.</p>
          <form className="search-panel" onSubmit={submitSearch} aria-label="Search doctors">
            <label className="search-field"><span>Specialty</span><select value={specialty} onChange={event => setSpecialty(event.target.value)}><option value="">Any specialty</option>{(specialties.data ?? ["Family Medicine", "Cardiology", "Dermatology", "Pediatrics"]).map(item => <option key={item} value={item}>{item}</option>)}</select></label>
            <span className="search-divider" aria-hidden="true" />
            <label className="search-field location-field"><span>Where</span><input value={location} onChange={event => setLocation(event.target.value)} placeholder="City or clinic" /></label>
            <span className="search-divider search-divider-last" aria-hidden="true" />
            <label className="search-field mode-field"><span>Visit type</span><select value={consultationType} onChange={event => setConsultationType(event.target.value)}><option value="">Any type</option><option value="in_person">In-person</option><option value="online">Online</option></select></label>
            <label className="search-field availability-field"><span>Available on</span><input type="date" min={dateInputValue(1)} value={availableDate} onChange={event => setAvailableDate(event.target.value)} aria-label="Filter doctors by available date" /></label>
            <button className="button button-primary search-submit" type="submit" aria-label="Search doctors"><Search size={18} /><span>Find care</span></button>
          </form>
          <div className="trust-note"><ShieldCheck size={16} /><span>Clear choices. Thoughtful care. Your details stay yours.</span></div>
        </div>
        <div className="hero-art" aria-label="A sample weekly appointment plan">
          <div className="art-halo" />
          <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
          <div className="hero-sprig sprig-one">✳</div><div className="hero-sprig sprig-two">✦</div>
          <div className="care-card">
            <div className="care-card-top"><div className="card-icon"><CalendarDays size={19} /></div><span className="mini-status"><span /> Open this week</span></div>
            <span className="card-overline">A good place to start</span>
            <h2>Your next visit,<br /><em>on your terms.</em></h2>
            <div className="mini-appointment">
              <div className="mini-doctor-avatar">MB</div>
              <div><strong>Dr. Maya Bennett</strong><span>Family medicine</span></div>
              <div className="mini-time"><Clock3 size={13} /> 10:30</div>
            </div>
            <div className="card-availability"><span className="availability-line" /><div><b>7</b><small>days ahead</small></div><span className="availability-line" /><div><b>2</b><small>ways to meet</small></div></div>
            <div className="privacy-note"><Check size={13} /> Your visit details are private</div>
          </div>
          <div className="floating-note"><span className="floating-icon"><HeartPulse size={16} /></span><span>Care, made a little easier.</span></div>
        </div>
      </section>

      <section className="sample-ribbon"><div className="section-shell ribbon-inner"><Sparkles size={15} /><span>DEMO PREVIEW</span><p>Doctor listings are fictional sample profiles. Sign in to request an appointment.</p><Link href="/login">How sign-in works <ArrowUpRight size={14} /></Link></div></section>

      <section id="doctor-results" className="section-shell results-section">
        <div className="section-heading-row"><div><span className="section-kicker">A few good places to begin</span><h2>{isSearch ? "Doctors for your search" : "Meet your care team"}</h2><p>{isSearch ? "Refine specialty, location, visit type or the date you need; results reflect open slots." : "Explore fictional sample profiles. Every real appointment request requires an authenticated account."}</p></div><Link className="text-link view-all-link" href="/find-doctor">Browse doctors <ArrowRight size={16} /></Link></div>
        {doctors.isLoading ? <div className="doctor-grid" aria-label="Loading doctor listings"><div className="skeleton-card" /><div className="skeleton-card" /><div className="skeleton-card" /></div> : doctors.error ? <div className="inline-alert" role="alert">Doctor listings could not be loaded. Please try again in a moment.</div> : doctors.data?.length ? <div className="doctor-grid">{doctors.data.slice(0, isSearch ? 20 : 3).map((doctor, index) => <DoctorCard key={doctor.slug} doctor={doctor} index={index} />)}</div> : <div className="empty-listing"><span className="empty-icon"><Search size={21} /></span><h3>No doctors match those filters yet</h3><p>Try a nearby city or choose “Any specialty” to see more options.</p><button className="button button-outline" onClick={() => { setSpecialty(""); setLocation(""); setConsultationType(""); setAvailableDate(""); }}>Clear filters</button></div>}
        {!isSearch && <div className="section-footnote">Sample profiles are illustrative only; no real clinician or patient details are shown.</div>}
      </section>

      <section id="how-it-works" className="how-section"><div className="section-shell how-inner"><div className="how-intro"><span className="section-kicker">Simple by design</span><h2>Three small steps<br /><em>toward better care.</em></h2><p>A clear path from “I should book” to a time on your calendar.</p><Link href="/find-doctor" className="button button-dark">Find a doctor <ArrowRight size={16} /></Link></div><div className="steps-list"><div className="step-item"><span className="step-number">01</span><span className="step-icon"><Search size={18} /></span><div><h3>Find someone who fits</h3><p>Browse by specialty, location and the kind of visit you need.</p></div><ArrowDown className="step-arrow" size={18} /></div><div className="step-item"><span className="step-number">02</span><span className="step-icon"><CalendarDays size={18} /></span><div><h3>Choose a time that works</h3><p>See open slots and select in-person or online care.</p></div><ArrowDown className="step-arrow" size={18} /></div><div className="step-item"><span className="step-number">03</span><span className="step-icon"><Check size={18} /></span><div><h3>Get a clear decision</h3><p>Track your request and receive an update when your doctor responds.</p></div><span className="step-check"><Check size={15} /></span></div></div></div></section>

      <section className="doctor-invite section-shell"><div className="invite-leaf">✳</div><div><span className="section-kicker">For clinicians</span><h2>Make room for more<br /><em>good care.</em></h2><p>Set your availability, review requests and keep every visit organized.</p><Link href="/register/doctor" className="button button-primary">Join as a doctor <ArrowUpRight size={16} /></Link></div><div className="invite-side"><span className="invite-side-icon"><Video size={18} /></span><strong>One place for your schedule</strong><p>Manage in-person and online requests with clear patient-provided notes.</p></div></section>
    </main>
    <footer className="site-footer"><div className="section-shell footer-inner"><Link href="/" className="brand"><span className="brand-mark"><HeartPulse size={17} /></span><span>carebook</span></Link><p>Fictional demo profiles · No real patient data</p><div><Link href="/patient/dashboard">Patient area</Link><Link href="/doctor/dashboard">Doctor area</Link><Link href="/admin/dashboard">Admin</Link></div></div></footer>
  </div>;
}
