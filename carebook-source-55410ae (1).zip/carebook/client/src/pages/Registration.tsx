import { ArrowLeft, ArrowRight, CheckCircle2, Clock3, ShieldCheck, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import CarebookHeader from "@/components/CarebookHeader";
import { dateInputValue } from "@/lib/carebook";
import { trpc } from "@/lib/trpc";

function SignInNeeded({ kind }: { kind: "patient" | "doctor" }) {
  return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="form-page-card"><span className="form-symbol"><ShieldCheck size={24} /></span><span className="section-kicker">Secure access</span><h1>Sign in to continue</h1><p>Carebook uses your authenticated Manus account to protect contact details and appointment information. After signing in, return here to finish setting up your {kind} profile.</p><button className="button button-primary" onClick={() => startLogin()}>Continue with Manus <ArrowRight size={17} /></button><Link href="/" className="text-link">Back to Carebook</Link></div></main></div>;
}

export function PatientRegistration() {
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [medicalNotes, setMedicalNotes] = useState("");
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const save = trpc.account.registerPatient.useMutation({ onSuccess: async () => { await utils.account.profile.invalidate(); setLocation("/patient/dashboard"); } });
  useEffect(() => { if (auth.user?.name) setName(auth.user.name); }, [auth.user?.name]);

  if (auth.loading || (auth.user && account.isLoading)) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="loading-card">Checking your account…</div></main></div>;
  if (!auth.user) return <SignInNeeded kind="patient" />;
  if (account.data?.role === "admin") return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Admin account detected</h1><p>Use the admin workspace to manage this service.</p><Link href="/admin/dashboard" className="button button-primary">Open admin dashboard</Link></div></main></div>;
  if (account.data?.role === "doctor") return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Your account is set up as a doctor</h1><p>Patient information stays separate from your doctor account.</p><Link href="/doctor/dashboard" className="button button-primary">Open doctor dashboard</Link></div></main></div>;

  const submit = async (event: React.FormEvent) => { event.preventDefault(); setError(""); try { await save.mutateAsync({ name, phone, dateOfBirth, medicalNotes }); } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not save your profile."); } };
  return <div className="site-page"><CarebookHeader /><main className="page-wrap registration-wrap"><Link href="/" className="back-link"><ArrowLeft size={16} /> Back to Carebook</Link><div className="form-page-card form-page-wide"><div className="form-symbol"><UserRound size={23} /></div><span className="section-kicker">Patient profile</span><h1>Let's make your care easier.</h1><p>Set up a few details to request and manage appointments. Your information is private to your account.</p><form className="stacked-form" onSubmit={submit}>
    <label className="form-label" htmlFor="patient-name">Full name</label><input className="form-control" id="patient-name" required minLength={2} maxLength={100} value={name} onChange={event => setName(event.target.value)} />
    <label className="form-label" htmlFor="patient-email">Email on your signed-in account</label><input className="form-control" id="patient-email" type="email" value={auth.user.email ?? ""} readOnly aria-readonly="true" />
    <div className="form-row"><div><label className="form-label" htmlFor="patient-phone">Phone</label><input className="form-control" id="patient-phone" type="tel" maxLength={40} value={phone} onChange={event => setPhone(event.target.value)} placeholder="(555) 123-4567" /></div><div><label className="form-label" htmlFor="patient-dob">Date of birth <span className="optional-label">Optional</span></label><input className="form-control" id="patient-dob" type="date" max={dateInputValue()} value={dateOfBirth} onChange={event => setDateOfBirth(event.target.value)} /></div></div>
    <label className="form-label" htmlFor="patient-notes">Medical notes <span className="optional-label">Optional</span></label><textarea className="form-control textarea-control" id="patient-notes" value={medicalNotes} onChange={event => setMedicalNotes(event.target.value)} maxLength={2000} placeholder="Anything you'd like your care team to know" />
    {error && <div className="inline-alert" role="alert">{error}</div>}<button className="button button-primary button-wide" disabled={save.isPending}>{save.isPending ? "Saving profile…" : "Save patient profile"} <ArrowRight size={17} /></button><p className="form-footnote"><ShieldCheck size={14} /> Medical notes are visible only to you and the doctor for an appointment you request.</p>
  </form></div></main></div>;
}

export function DoctorRegistration() {
  const [, params] = useRoute("/register/doctor");
  void params;
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("Family Medicine");
  const [qualifications, setQualifications] = useState("");
  const [experienceYears, setExperienceYears] = useState(0);
  const [languages, setLanguages] = useState("English");
  const [clinicName, setClinicName] = useState("");
  const [location, setClinicLocation] = useState("");
  const [fee, setFee] = useState(95);
  const [bio, setBio] = useState("");
  const [online, setOnline] = useState(true);
  const [inPerson, setInPerson] = useState(true);
  const [error, setError] = useState("");
  const specialties = trpc.doctors.specialties.useQuery();
  const utils = trpc.useUtils();
  const doctorProfile = account.data?.role === "doctor" ? account.data.profile : null;
  const [timezone, setTimezone] = useState(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
  const save = trpc.account.registerDoctor.useMutation({ onSuccess: async () => { await utils.account.profile.invalidate(); setLocation("/doctor/dashboard"); } });
  useEffect(() => { if (auth.user?.name) setName(auth.user.name); }, [auth.user?.name]);
  useEffect(() => {
    if (!doctorProfile) return;
    setName(doctorProfile.name);
    setSpecialty(doctorProfile.specialty);
    setQualifications(doctorProfile.qualifications);
    setExperienceYears(doctorProfile.experienceYears);
    setLanguages(doctorProfile.languages.join(", "));
    setClinicName(doctorProfile.clinicName);
    setClinicLocation(doctorProfile.location);
    setFee(doctorProfile.fee);
    setBio(doctorProfile.bio ?? "");
    setOnline(doctorProfile.consultationTypes.includes("online"));
    setInPerson(doctorProfile.consultationTypes.includes("in_person"));
    setTimezone(doctorProfile.timezone);
  }, [doctorProfile]);

  if (auth.loading || (auth.user && account.isLoading)) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="loading-card">Checking your account…</div></main></div>;
  if (!auth.user) return <SignInNeeded kind="doctor" />;
  if (account.data?.role === "patient") return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Your account is set up as a patient</h1><p>To keep role access clear, doctor features require a separate account profile.</p><Link href="/patient/dashboard" className="button button-primary">Open patient dashboard</Link></div></main></div>;
  if (account.data?.role === "admin") return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Admin account detected</h1><p>Use the admin workspace to manage doctors.</p><Link href="/admin/dashboard" className="button button-primary">Open admin dashboard</Link></div></main></div>;

  const submit = async (event: React.FormEvent) => { event.preventDefault(); setError(""); if (!online && !inPerson) { setError("Choose at least one consultation type."); return; } try { await save.mutateAsync({ name, specialty, qualifications, experienceYears, languages, clinicName, location, fee, bio, timezone, consultationTypes: [...(inPerson ? ["in_person" as const] : []), ...(online ? ["online" as const] : [])] }); } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not save your profile."); } };
  return <div className="site-page"><CarebookHeader /><main className="page-wrap registration-wrap"><Link href="/" className="back-link"><ArrowLeft size={16} /> Back to Carebook</Link><div className="form-page-card form-page-wide"><div className="form-symbol"><CheckCircle2 size={23} /></div><span className="section-kicker">Clinician profile</span><h1>Make room for good care.</h1><p>Set up your practice profile. An admin will review it before it appears in public search.</p><form className="stacked-form" onSubmit={submit}>
    <label className="form-label" htmlFor="doctor-name">Display name</label><input className="form-control" id="doctor-name" required minLength={2} maxLength={140} value={name} onChange={event => setName(event.target.value)} />
    <div className="form-row"><div><label className="form-label" htmlFor="doctor-specialty">Specialty</label><select className="form-control" id="doctor-specialty" value={specialty} onChange={event => setSpecialty(event.target.value)}>{(specialties.data ?? ["Family Medicine", "Cardiology", "Dermatology", "Pediatrics"]).map(item => <option key={item}>{item}</option>)}</select></div><div><label className="form-label" htmlFor="doctor-qualification">Qualifications</label><input className="form-control" id="doctor-qualification" required maxLength={255} value={qualifications} onChange={event => setQualifications(event.target.value)} placeholder="MD, board certification" /></div></div>
    <div className="form-row"><div><label className="form-label" htmlFor="doctor-experience">Years of experience</label><input className="form-control" id="doctor-experience" type="number" min={0} max={80} value={experienceYears} onChange={event => setExperienceYears(Number(event.target.value))} /></div><div><label className="form-label" htmlFor="doctor-languages">Languages</label><input className="form-control" id="doctor-languages" required maxLength={255} value={languages} onChange={event => setLanguages(event.target.value)} placeholder="English, Spanish" /></div></div>
    <div className="form-row"><div><label className="form-label" htmlFor="clinic-name">Clinic name</label><input className="form-control" id="clinic-name" required maxLength={160} value={clinicName} onChange={event => setClinicName(event.target.value)} /></div><div><label className="form-label" htmlFor="clinic-location">Clinic location</label><input className="form-control" id="clinic-location" required maxLength={160} value={location} onChange={event => setClinicLocation(event.target.value)} placeholder="City, State" /></div></div>
    <div className="form-row"><div><label className="form-label" htmlFor="clinic-timezone">Clinic timezone (IANA)</label><input className="form-control" id="clinic-timezone" value={timezone} onChange={event => setTimezone(event.target.value)} placeholder="America/Los_Angeles" required /></div><div><label className="form-label" htmlFor="doctor-fee">Consultation fee (USD)</label><input className="form-control" id="doctor-fee" type="number" min={0} max={5000} value={fee} onChange={event => setFee(Number(event.target.value))} /></div><div><label className="form-label" htmlFor="doctor-bio">Short bio <span className="optional-label">Optional</span></label><input className="form-control" id="doctor-bio" maxLength={1000} value={bio} onChange={event => setBio(event.target.value)} placeholder="Your approach to patient care" /></div></div>
    <fieldset className="consultation-checkboxes"><legend className="form-label">Consultation types</legend><label><input type="checkbox" checked={inPerson} onChange={event => setInPerson(event.target.checked)} /> In-person</label><label><input type="checkbox" checked={online} onChange={event => setOnline(event.target.checked)} /> Online</label></fieldset>
    {error && <div className="inline-alert" role="alert">{error}</div>}<button className="button button-primary button-wide" disabled={save.isPending}>{save.isPending ? "Saving profile…" : doctorProfile ? "Save doctor profile" : "Create doctor profile"} <ArrowRight size={17} /></button><p className="form-footnote"><Clock3 size={14} /> New doctor profiles are reviewed before listing. You can set weekly hours after approval.</p>
  </form></div></main></div>;
}
