import { ArrowLeft, ArrowUpRight, BadgeCheck, CalendarClock, CalendarDays, Check, CircleHelp, Clock3, Languages, MapPin, ShieldCheck, Video, Wallet } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import CarebookHeader from "@/components/CarebookHeader";
import { initials } from "@/lib/carebook";
import { clinicDateInputValue } from "@shared/timezone";
import { trpc } from "@/lib/trpc";
import type { ConsultationMode } from "@shared/carebook";

export default function DoctorProfile() {
  const [, params] = useRoute("/doctors/:slug");
  const slug = params?.slug ?? "";
  const [, setLocation] = useLocation();
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  const doctor = trpc.doctors.detail.useQuery({ slug }, { enabled: Boolean(slug) });
  const [date, setDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [mode, setMode] = useState<ConsultationMode>("in_person");
  const [reason, setReason] = useState("");
  const [notice, setNotice] = useState("");
  const slots = trpc.doctors.slots.useQuery({ slug, date }, { enabled: Boolean(slug && date) });
  const utils = trpc.useUtils();
  const request = trpc.patient.requestAppointment.useMutation({ onSuccess: async result => { await utils.patient.dashboard.invalidate(); setLocation(`/appointments/${result.id}`); }, onError: error => setNotice(error.message) });
  const clinicTimeZone = doctor.data?.timezone ?? "";
  const availableDays = useMemo(() => clinicTimeZone ? Array.from({ length: 7 }, (_, index) => clinicDateInputValue(index + 1, clinicTimeZone)) : [], [clinicTimeZone]);
  const offeredTypes = (doctor.data?.consultationTypes ?? []) as ConsultationMode[];
  const offeredTypesKey = offeredTypes.join("|");
  useEffect(() => { if (offeredTypes.length && !offeredTypes.includes(mode)) setMode(offeredTypes[0]); }, [offeredTypesKey, mode]);
  useEffect(() => { if (availableDays.length) setDate(current => availableDays.includes(current) ? current : availableDays[0]); }, [availableDays]);

  if (doctor.isLoading) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="loading-card">Loading doctor profile…</div></main></div>;
  if (!doctor.data || doctor.error) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Doctor profile not found</h1><p>This listing may be inactive or no longer available.</p><Link href="/find-doctor" className="button button-primary">Browse doctors</Link></div></main></div>;
  const profile = doctor.data;
  const types = profile.consultationTypes as ConsultationMode[];

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setNotice("");
    if (!auth.user) { setNotice("Sign in with your account before requesting an appointment."); return; }
    if (account.data?.role !== "patient") { setNotice(account.data?.role ? "This booking flow is for patient accounts." : "Complete a patient profile before requesting an appointment."); return; }
    if (!selectedSlot) { setNotice("Choose an available appointment time first."); return; }
    try { await request.mutateAsync({ doctorSlug: slug, slotStart: selectedSlot, mode, reason }); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not send your request."); }
  };

  return <div className="site-page"><CarebookHeader /><main className="section-shell profile-page">
    <Link href="/find-doctor" className="back-link"><ArrowLeft size={16} /> Back to doctors</Link>
    <div className="profile-layout">
      <div className="profile-main">
        <section className="profile-hero-card">
          <div className="doctor-avatar profile-avatar avatar-sage" aria-hidden="true"><span>{initials(profile.name)}</span><i className="avatar-sparkle">✳</i></div>
          <div className="profile-summary"><span className="specialty-label">{profile.specialty}</span><h1>{profile.name}</h1><p className="credentials">{profile.qualifications} <span>·</span> {profile.experienceYears} years of experience</p><div className="profile-tags"><span className="verified-pill"><span className="verified-dot"><BadgeCheck size={13} /></span> Verified profile</span>{profile.isSample && <span className="sample-tag">Fictional sample</span>}</div></div>
          <div className="profile-fee"><span>Consultation</span><strong>${profile.fee}</strong><small>per visit</small></div>
        </section>
        <section className="profile-content-card"><span className="section-kicker">A little about</span><p className="profile-bio">{profile.bio}</p><div className="profile-facts"><div><span className="fact-icon"><MapPin size={17} /></span><span><small>Clinic</small><strong>{profile.clinicName}</strong><em>{profile.location}</em></span></div><div><span className="fact-icon"><Languages size={17} /></span><span><small>Languages</small><strong>{(profile.languages as string[]).join(", ")}</strong></span></div><div><span className="fact-icon"><Video size={17} /></span><span><small>Visit options</small><strong>{types.includes("online") ? "In-person or online" : "In-person"}</strong></span></div><div><span className="fact-icon"><CalendarClock size={17} /></span><span><small>Experience</small><strong>{profile.experienceYears} years</strong></span></div></div></section>
        <section className="booking-card" id="availability">
          <div className="booking-heading"><div><span className="section-kicker">Choose a time</span><h2>Request an appointment</h2><p>Times shown in {profile.timezone} clinic time. Requests are confirmed by the doctor.</p></div><div className="booking-shield"><ShieldCheck size={19} /><span>Private<br />by design</span></div></div>
          <form onSubmit={submit}>
            <label className="form-label" htmlFor="appointment-date">Available date</label>
            <select className="form-control date-select" id="appointment-date" value={date} onChange={event => { setDate(event.target.value); setSelectedSlot(""); }}><option value="">Choose a date</option>{availableDays.map((day, index) => <option value={day} key={day}>{new Intl.DateTimeFormat("en-US", { weekday: "long", month: "long", day: "numeric", timeZone: "UTC" }).format(new Date(`${day}T12:00:00Z`))}{index === 0 ? " · Next day" : ""}</option>)}</select>
            <div className="slot-list-label"><span className="form-label">Available times</span>{slots.data && <span>{slots.data.length} open</span>}</div>
            {slots.isLoading ? <div className="slot-loading">Checking availability…</div> : slots.error ? <div className="inline-alert" role="alert">Could not load appointment times. Please try again.</div> : slots.data?.length ? <div className="slot-grid">{slots.data.map(slot => <button type="button" key={slot} className={`slot-button ${selectedSlot === slot ? "slot-selected" : ""}`} onClick={() => setSelectedSlot(slot)} aria-pressed={selectedSlot === slot}>{slot.slice(11)}{selectedSlot === slot && <Check size={14} />}</button>)}</div> : <div className="slots-empty"><CircleHelp size={17} /><span>No open times for this date. Choose another day.</span></div>}
            <fieldset className="mode-fieldset"><legend className="form-label">How would you like to meet?</legend><div className="mode-options">{types.map(type => <label className={`mode-option ${mode === type ? "mode-option-active" : ""}`} key={type}><input type="radio" name="mode" value={type} checked={mode === type} onChange={() => setMode(type)} /><span className="mode-icon">{type === "online" ? <Video size={17} /> : <MapPin size={17} />}</span><span><strong>{type === "online" ? "Online visit" : "In-person"}</strong><small>{type === "online" ? "Secure video call" : profile.clinicName}</small></span></label>)}</div></fieldset>
            <label className="form-label" htmlFor="visit-reason">Reason for visit <span className="optional-label">Optional</span></label><textarea className="form-control textarea-control" id="visit-reason" value={reason} onChange={event => setReason(event.target.value)} maxLength={1000} placeholder="Share a brief note for the doctor" />
            {notice && <div className="inline-alert" role="alert">{notice} {!auth.user && <button type="button" className="inline-link" onClick={() => setLocation("/login")}>Sign in</button>}</div>}
            {auth.user && account.data?.role === null && <p className="helper-note">You'll need a patient profile before requesting a visit. <Link href="/register/patient">Set up your profile</Link></p>}
            <button className="button button-primary button-wide" type="submit" disabled={request.isPending || !selectedSlot}>{request.isPending ? "Sending request…" : "Request appointment"}<ArrowUpRight size={17} /></button>
            <p className="privacy-note"><ShieldCheck size={14} /> Your appointment is pending until the doctor responds.</p>
          </form>
        </section>
      </div>
      <aside className="profile-aside"><div className="aside-card"><span className="aside-icon"><Wallet size={19} /></span><h3>Visit details</h3><div className="aside-row"><span>Consultation fee</span><strong>${profile.fee}</strong></div><div className="aside-row"><span>Visit type</span><strong>{types.includes("online") && types.includes("in_person") ? "In-person or online" : types.includes("online") ? "Online" : "In-person"}</strong></div><div className="aside-row"><span>Response</span><strong>Doctor confirms</strong></div><p>Payment is handled directly at your visit; no payment details are collected here.</p></div>{profile.isSample && <div className="aside-note"><ShieldCheck size={17} /><p><strong>Sample listing</strong><br />This doctor profile is fictional and included for demo use only.</p></div>}<Link className="aside-help" href="/login"><CircleHelp size={16} /> How booking works</Link></aside>
    </div>
  </main></div>;
}
