import { ArrowLeft, ArrowRight, CalendarCheck2, CalendarDays, CircleCheck, Clock3, MapPin, MessageSquareText, ShieldCheck, Video } from "lucide-react";
import { Link, useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import CarebookHeader from "@/components/CarebookHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { formatClinicSlot } from "@/lib/carebook";
import { trpc } from "@/lib/trpc";

export default function AppointmentDetail() {
  const [, params] = useRoute("/appointments/:id");
  const id = params?.id ?? "";
  const auth = useAuth();
  const account = trpc.account.profile.useQuery(undefined, { enabled: Boolean(auth.user), retry: false });
  const detail = trpc.appointments.detail.useQuery({ id }, { enabled: Boolean(id && auth.user), retry: false });
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const cancel = trpc.patient.cancelAppointment.useMutation({ onSuccess: async () => { await utils.patient.dashboard.invalidate(); await utils.appointments.detail.invalidate({ id }); }, onError: error => window.alert(error.message) });

  if (!auth.user) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><span className="empty-icon"><ShieldCheck size={22} /></span><h1>Sign in to view this appointment</h1><p>Appointment details are available only to the patient, the assigned doctor, and an administrator.</p><button className="button button-primary" onClick={() => startLogin()}>Sign in securely</button></div></main></div>;
  if (detail.isLoading || account.isLoading) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="loading-card">Loading appointment details…</div></main></div>;
  if (!detail.data || detail.error) return <div className="site-page"><CarebookHeader /><main className="page-wrap"><div className="empty-state"><h1>Appointment not found</h1><p>This appointment may have been removed, or your account may not have access.</p><Link href="/" className="button button-primary">Return home</Link></div></main></div>;
  const item = detail.data;
  const patientCanCancel = account.data?.role === "patient" && (item.status === "pending" || item.status === "approved");
  const dashboard = account.data?.role === "doctor" ? "/doctor/dashboard" : account.data?.role === "admin" ? "/admin/dashboard" : "/patient/dashboard";

  return <div className="site-page"><CarebookHeader /><main className="section-shell appointment-detail-page"><Link href={dashboard} className="back-link"><ArrowLeft size={16} /> Back to your workspace</Link><section className="confirmation-card">
    <div className={`confirmation-icon confirmation-${item.status}`}>{item.status === "approved" ? <CircleCheck size={27} /> : <CalendarCheck2 size={26} />}</div>
    <span className="section-kicker">Appointment details</span><h1>{item.status === "pending" ? "Your request is in." : item.status === "approved" ? "Your visit is confirmed." : item.status === "rejected" ? "An update on your request." : "This appointment was cancelled."}</h1><p className="confirmation-lede">{item.status === "pending" ? "The doctor will review your request. We'll let you know when there's an update." : item.status === "approved" ? "Your appointment has been approved. Keep these details handy for your visit." : item.status === "rejected" ? "The doctor wasn't able to accept this appointment request." : "This appointment no longer appears in the doctor's available schedule."}</p>
    <div className="confirmation-status"><span>Current status</span><StatusBadge status={item.status} /></div>
    <div className="confirmation-details"><div className="confirmation-detail-row"><span className="detail-icon"><CalendarDays size={18} /></span><span><small>Date & time · clinic local</small><strong>{formatClinicSlot(item.slotStartUtc, item.timeZone)}</strong></span></div><div className="confirmation-detail-row"><span className="detail-icon">{item.mode === "online" ? <Video size={18} /> : <MapPin size={18} />}</span><span><small>{item.mode === "online" ? "Visit type" : "Clinic"}</small><strong>{item.mode === "online" ? "Online visit" : item.doctor?.clinicName}</strong>{item.mode === "in_person" && <em>{item.doctor?.location}</em>}</span></div><div className="confirmation-detail-row"><span className="detail-icon"><Clock3 size={18} /></span><span><small>Doctor</small><strong>{item.doctor?.name ?? "Carebook clinician"}</strong><em>{item.doctor?.specialty}</em></span></div>{item.reason && <div className="confirmation-detail-row"><span className="detail-icon"><MessageSquareText size={18} /></span><span><small>Your note</small><strong className="note-value">{item.reason}</strong></span></div>}{item.decisionMessage && <div className="decision-message"><strong>Doctor's message</strong><p>{item.decisionMessage}</p></div>}</div>
    {patientCanCancel && <button className="button button-outline cancel-confirmation" disabled={cancel.isPending} onClick={() => { if (window.confirm("Cancel this appointment? The slot will become available again.")) cancel.mutate({ id }); }}>{cancel.isPending ? "Cancelling…" : "Cancel appointment"}</button>}
    {item.status === "rejected" || item.status === "cancelled" ? <Link className="button button-primary button-wide" href="/find-doctor">Find another appointment <ArrowRight size={16} /></Link> : <Link className="button button-outline button-wide" href={dashboard}>Go to your dashboard <ArrowRight size={16} /></Link>}
    <p className="privacy-note"><ShieldCheck size={14} /> Appointment details are only visible to the patient, assigned doctor and admin.</p>
  </section></main></div>;
}
