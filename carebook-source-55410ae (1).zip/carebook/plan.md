# Carebook implementation plan

## Architecture and assumptions

Carebook will remain on the initialized managed `web-db-user` stack: React + TypeScript + Vite on the frontend, Express + tRPC on the backend, and Drizzle ORM over the managed MySQL database. Use the existing Manus OAuth flow for account identity and the starter's Preview-compatible session cookie. Do not fabricate a logged-in user or add another auth provider.

The application will add patient and doctor profiles, doctor schedules and blocked times, specialties, appointments, slot reservations, in-app notifications, and basic site settings. `users.role` is the server-authoritative role (`user`, `patient`, `doctor`, or `admin`); onboarding atomically grants at most one patient/doctor role and admin authority remains trusted and non-self-assignable. Doctor profiles stay unverified until an admin approves them, and changes to reviewed profile fields revoke verification. Public discovery returns a whitelisted doctor projection that omits account IDs and review metadata; sample listings remain clearly identified. Appointment requests require a real authenticated patient. Each appointment preserves the doctor's clinic-local time, IANA timezone and exact start/end UTC offsets while storing canonical UTC start/end instants for chronology, cutoff, overlap checks, and repeated-hour disambiguation. Booking, schedule changes, blocked times, patient deactivation and appointment status transitions use database row locks and interval-overlap checks so concurrent changes cannot create double-booking or conflicting outcomes; rejected/cancelled requests release reservations. Inactive patients and doctors cannot read appointment details or mutate clinic records. Notifications are stored in-app. The default approved-appointment cancellation cutoff is 24 hours and is configurable by an admin. Patient date-of-birth input is validated against the real calendar and future dates are rejected. Sample listings use clearly fictional data; no patient sample records are seeded.

The backend will enforce actor ownership and role checks in tRPC procedures. The user interface will expose validation and clear pending/empty/error states. Backend/database functions remain isolated from route components. Include `.env.example` and a README with local start, migration, and seed steps. Any capability not wired to a live external provider (notably email delivery) will be described honestly; in-app confirmation/status notifications are the initial notification channel.

## Project structure

- `client/src/pages/` — home/search, doctor detail, authentication/onboarding, patient/doctor/admin dashboards, appointment detail.
- `client/src/components/` — shared navigation, doctor cards, role gate and status badges; page modules own their booking and dashboard sections.
- `client/src/lib/` — typed tRPC client and UI helpers.
- `server/routers.ts` — role-gated tRPC API surface and input validation.
- `server/carebookDb.ts` — Drizzle-backed domain queries, row-locked role/profile changes, interval-safe appointment reservation/status transitions, and notification writes; `server/db.ts` remains the starter managed-database connector.
- `server/_core/` — preserve the existing OAuth/session/context/server runtime.
- `drizzle/schema.ts`, `drizzle/` — additive managed-MySQL schema and migrations for domain tables; fictional doctor fixtures only.
- `shared/` — shared types and constants, including clinic-time conversion helpers.
- `client/public/` — static route manifest and Carebook mark, served by the Vite client root.

## Design direction

- **Design movement:** warm editorial healthcare, combining Scandinavian restraint with a modern neighborhood-clinic sensibility.
- **Core principles:** reassuring but not clinical-cold; information hierarchy before decoration; friction-light booking; accessible contrast and generous touch targets.
- **Color philosophy:** deep evergreen/teal anchors trust and care; warm ivory backgrounds keep the interface calm; muted sage and apricot accent status and actions without confusing urgency.
- **Layout paradigm:** asymmetric editorial landing page with a left-aligned promise and appointment-search panel; flowing list/results surfaces rather than a centered grid-only template; dashboards use clear grouped panels.
- **Signature elements:** compact care-mark combining a rounded cross and leaf; soft appointment-slot chips; gentle green status markers and warm off-white surfaces.
- **Interaction philosophy:** filters update results immediately; booking is a short, explicit sequence; status changes always explain what happened and what comes next.
- **Animation:** subtle 140–220 ms opacity/translate transitions for panels and selection; no looping decoration or motion that competes with clinical information; honor reduced-motion preferences.
- **Typography system:** a readable sans-serif UI stack for controls and body copy, paired with a restrained serif display face for major headings; clear size/weight/line-height hierarchy and minimum 16px body text on mobile.
- **Brand essence:** a clearer route from searching for care to a confirmed visit; calm, capable, human.
- **Brand voice:** plain, reassuring and specific. Example: “Care that fits your day.” / “Choose a time that works for you.”
- **Wordmark & logo:** lowercase “carebook” wordmark with an original rounded leaf-cross mark, not a default-font wordmark alone.
- **Signature brand color:** evergreen `#176B5B`, used for the primary action and brand mark.

## Delivery behavior

Deliver a responsive working Preview in the managed project. Keep the actual project files organized, run language diagnostics, application checks and a production build, verify the route manifest, then save a canonical checkpoint. Do not claim production publication unless a successful publish is explicitly confirmed. The backend and database are configured as managed resources from initialization; migration and seed setup steps will be documented. No real patient data will be included.
