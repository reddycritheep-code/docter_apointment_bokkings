import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  smallint,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the existing Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "patient", "doctor", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const patientProfiles = mysqlTable("patient_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  phone: varchar("phone", { length: 40 }),
  dateOfBirth: varchar("date_of_birth", { length: 10 }),
  medicalNotes: text("medical_notes"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const doctorProfiles = mysqlTable("doctor_profiles", {
  slug: varchar("slug", { length: 80 }).primaryKey(),
  userId: int("user_id").unique().references(() => users.id, { onDelete: "set null" }),
  name: varchar("name", { length: 140 }).notNull(),
  specialty: varchar("specialty", { length: 100 }).notNull(),
  qualifications: varchar("qualifications", { length: 255 }).notNull(),
  experienceYears: int("experience_years").notNull().default(0),
  languages: varchar("languages", { length: 255 }).notNull().default("English"),
  clinicName: varchar("clinic_name", { length: 160 }).notNull(),
  location: varchar("location", { length: 160 }).notNull(),
  consultationTypes: varchar("consultation_types", { length: 255 }).notNull().default('["in_person"]'),
  fee: int("fee").notNull().default(0),
  bio: text("bio"),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/New_York"),
  verified: boolean("verified").notNull().default(false),
  active: boolean("active").notNull().default(true),
  isSample: boolean("is_sample").notNull().default(false),
  profileRevision: int("profile_revision").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => ({
  specialtyIndex: index("doctor_profiles_specialty_idx").on(table.specialty),
  locationIndex: index("doctor_profiles_location_idx").on(table.location),
}));

export const doctorSchedules = mysqlTable("doctor_schedules", {
  id: int("id").autoincrement().primaryKey(),
  doctorSlug: varchar("doctor_slug", { length: 80 }).notNull().references(() => doctorProfiles.slug, { onDelete: "cascade" }),
  weekday: int("weekday").notNull(),
  startTime: varchar("start_time", { length: 5 }).notNull(),
  endTime: varchar("end_time", { length: 5 }).notNull(),
  slotMinutes: int("slot_minutes").notNull().default(30),
  active: boolean("active").notNull().default(true),
}, table => ({
  uniqueDay: uniqueIndex("doctor_schedule_day_unique").on(table.doctorSlug, table.weekday),
}));

export const blockedTimes = mysqlTable("blocked_times", {
  id: int("id").autoincrement().primaryKey(),
  doctorSlug: varchar("doctor_slug", { length: 80 }).notNull().references(() => doctorProfiles.slug, { onDelete: "cascade" }),
  startLocal: varchar("start_local", { length: 16 }).notNull(),
  endLocal: varchar("end_local", { length: 16 }).notNull(),
  startUtc: varchar("start_utc", { length: 24 }),
  endUtc: varchar("end_utc", { length: 24 }),
  timeZone: varchar("time_zone", { length: 64 }),
  note: varchar("note", { length: 160 }),
}, table => ({
  doctorStartIndex: index("blocked_times_doctor_start_idx").on(table.doctorSlug, table.startLocal),
  doctorUtcIndex: index("blocked_times_doctor_utc_idx").on(table.doctorSlug, table.startUtc),
}));

export const specialties = mysqlTable("specialties", {
  name: varchar("name", { length: 100 }).primaryKey(),
  active: boolean("active").notNull().default(true),
});

export const appointments = mysqlTable("appointments", {
  id: varchar("id", { length: 40 }).primaryKey(),
  patientUserId: int("patient_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  doctorSlug: varchar("doctor_slug", { length: 80 }).notNull().references(() => doctorProfiles.slug),
  slotStart: varchar("slot_start", { length: 16 }).notNull(),
  slotEnd: varchar("slot_end", { length: 16 }).notNull(),
  slotStartUtc: varchar("slot_start_utc", { length: 24 }),
  slotEndUtc: varchar("slot_end_utc", { length: 24 }),
  slotStartOffsetMinutes: smallint("slot_start_offset_minutes"),
  slotEndOffsetMinutes: smallint("slot_end_offset_minutes"),
  timeZone: varchar("time_zone", { length: 64 }),
  mode: mysqlEnum("mode", ["in_person", "online"]).notNull(),
  reason: text("reason"),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "cancelled"]).notNull().default("pending"),
  decisionMessage: text("decision_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => ({
  patientIndex: index("appointments_patient_idx").on(table.patientUserId, table.slotStart),
  doctorIndex: index("appointments_doctor_idx").on(table.doctorSlug, table.slotStart),
  doctorUtcIndex: index("appointments_doctor_utc_idx").on(table.doctorSlug, table.slotStartUtc),
}));

/** A unique row reserves an active (pending or approved) doctor slot. */
export const slotReservations = mysqlTable("slot_reservations", {
  id: int("id").autoincrement().primaryKey(),
  doctorSlug: varchar("doctor_slug", { length: 80 }).notNull().references(() => doctorProfiles.slug, { onDelete: "cascade" }),
  slotStart: varchar("slot_start", { length: 16 }).notNull(),
  appointmentId: varchar("appointment_id", { length: 40 }).notNull().unique().references(() => appointments.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, table => ({
  doctorSlotUnique: uniqueIndex("slot_reservations_doctor_slot_unique").on(table.doctorSlug, table.slotStart),
}));

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  appointmentId: varchar("appointment_id", { length: 40 }).references(() => appointments.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 140 }).notNull(),
  body: text("body").notNull(),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, table => ({ userIndex: index("notifications_user_idx").on(table.userId, table.readAt) }));

export const siteSettings = mysqlTable("site_settings", {
  key: varchar("key", { length: 100 }).primaryKey(),
  value: varchar("value", { length: 500 }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});
