ALTER TABLE `appointments` ADD `slot_start_offset_minutes` smallint;--> statement-breakpoint
ALTER TABLE `appointments` ADD `slot_end_offset_minutes` smallint;