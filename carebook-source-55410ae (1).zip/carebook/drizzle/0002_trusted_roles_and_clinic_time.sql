ALTER TABLE `users` MODIFY COLUMN `role` enum('user','patient','doctor','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
UPDATE `users` AS u SET `role` = CASE WHEN EXISTS (SELECT 1 FROM `doctor_profiles` d WHERE d.`user_id` = u.`id`) THEN 'doctor' WHEN EXISTS (SELECT 1 FROM `patient_profiles` p WHERE p.`user_id` = u.`id`) THEN 'patient' ELSE 'user' END WHERE u.`role` = 'user';--> statement-breakpoint
ALTER TABLE `appointments` ADD `slot_start_utc` varchar(24);--> statement-breakpoint
ALTER TABLE `appointments` ADD `slot_end_utc` varchar(24);--> statement-breakpoint
ALTER TABLE `appointments` ADD `time_zone` varchar(64);--> statement-breakpoint
ALTER TABLE `blocked_times` ADD `start_utc` varchar(24);--> statement-breakpoint
ALTER TABLE `blocked_times` ADD `end_utc` varchar(24);--> statement-breakpoint
ALTER TABLE `blocked_times` ADD `time_zone` varchar(64);--> statement-breakpoint
ALTER TABLE `doctor_profiles` ADD `profile_revision` int DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX `appointments_doctor_utc_idx` ON `appointments` (`doctor_slug`,`slot_start_utc`);--> statement-breakpoint
CREATE INDEX `blocked_times_doctor_utc_idx` ON `blocked_times` (`doctor_slug`,`start_utc`);
