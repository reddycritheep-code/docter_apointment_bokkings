CREATE TABLE `appointments` (
	`id` varchar(40) NOT NULL,
	`patient_user_id` int NOT NULL,
	`doctor_slug` varchar(80) NOT NULL,
	`slot_start` varchar(16) NOT NULL,
	`slot_end` varchar(16) NOT NULL,
	`mode` enum('in_person','online') NOT NULL,
	`reason` text,
	`status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
	`decision_message` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appointments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `blocked_times` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctor_slug` varchar(80) NOT NULL,
	`start_local` varchar(16) NOT NULL,
	`end_local` varchar(16) NOT NULL,
	`note` varchar(160),
	CONSTRAINT `blocked_times_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `doctor_profiles` (
	`slug` varchar(80) NOT NULL,
	`user_id` int,
	`name` varchar(140) NOT NULL,
	`specialty` varchar(100) NOT NULL,
	`qualifications` varchar(255) NOT NULL,
	`experience_years` int NOT NULL DEFAULT 0,
	`languages` varchar(255) NOT NULL DEFAULT 'English',
	`clinic_name` varchar(160) NOT NULL,
	`location` varchar(160) NOT NULL,
	`consultation_types` varchar(255) NOT NULL DEFAULT '["in_person"]',
	`fee` int NOT NULL DEFAULT 0,
	`bio` text,
	`timezone` varchar(64) NOT NULL DEFAULT 'America/New_York',
	`verified` boolean NOT NULL DEFAULT false,
	`active` boolean NOT NULL DEFAULT true,
	`is_sample` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `doctor_profiles_slug` PRIMARY KEY(`slug`),
	CONSTRAINT `doctor_profiles_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `doctor_schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctor_slug` varchar(80) NOT NULL,
	`weekday` int NOT NULL,
	`start_time` varchar(5) NOT NULL,
	`end_time` varchar(5) NOT NULL,
	`slot_minutes` int NOT NULL DEFAULT 30,
	`active` boolean NOT NULL DEFAULT true,
	CONSTRAINT `doctor_schedules_id` PRIMARY KEY(`id`),
	CONSTRAINT `doctor_schedule_day_unique` UNIQUE(`doctor_slug`,`weekday`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`appointment_id` varchar(40),
	`title` varchar(140) NOT NULL,
	`body` text NOT NULL,
	`read_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patient_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`phone` varchar(40),
	`date_of_birth` varchar(10),
	`medical_notes` text,
	`active` boolean NOT NULL DEFAULT true,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patient_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `patient_profiles_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `site_settings` (
	`key` varchar(100) NOT NULL,
	`value` varchar(500) NOT NULL,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_settings_key` PRIMARY KEY(`key`)
);
--> statement-breakpoint
CREATE TABLE `slot_reservations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctor_slug` varchar(80) NOT NULL,
	`slot_start` varchar(16) NOT NULL,
	`appointment_id` varchar(40) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `slot_reservations_id` PRIMARY KEY(`id`),
	CONSTRAINT `slot_reservations_appointment_id_unique` UNIQUE(`appointment_id`),
	CONSTRAINT `slot_reservations_doctor_slot_unique` UNIQUE(`doctor_slug`,`slot_start`)
);
--> statement-breakpoint
CREATE TABLE `specialties` (
	`name` varchar(100) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	CONSTRAINT `specialties_name` PRIMARY KEY(`name`)
);
--> statement-breakpoint
ALTER TABLE `appointments` ADD CONSTRAINT `appointments_patient_user_id_users_id_fk` FOREIGN KEY (`patient_user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `appointments` ADD CONSTRAINT `appointments_doctor_slug_doctor_profiles_slug_fk` FOREIGN KEY (`doctor_slug`) REFERENCES `doctor_profiles`(`slug`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `blocked_times` ADD CONSTRAINT `blocked_times_doctor_slug_doctor_profiles_slug_fk` FOREIGN KEY (`doctor_slug`) REFERENCES `doctor_profiles`(`slug`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `doctor_profiles` ADD CONSTRAINT `doctor_profiles_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `doctor_schedules` ADD CONSTRAINT `doctor_schedules_doctor_slug_doctor_profiles_slug_fk` FOREIGN KEY (`doctor_slug`) REFERENCES `doctor_profiles`(`slug`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_appointment_id_appointments_id_fk` FOREIGN KEY (`appointment_id`) REFERENCES `appointments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `patient_profiles` ADD CONSTRAINT `patient_profiles_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `slot_reservations` ADD CONSTRAINT `slot_reservations_doctor_slug_doctor_profiles_slug_fk` FOREIGN KEY (`doctor_slug`) REFERENCES `doctor_profiles`(`slug`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `slot_reservations` ADD CONSTRAINT `slot_reservations_appointment_id_appointments_id_fk` FOREIGN KEY (`appointment_id`) REFERENCES `appointments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `appointments_patient_idx` ON `appointments` (`patient_user_id`,`slot_start`);--> statement-breakpoint
CREATE INDEX `appointments_doctor_idx` ON `appointments` (`doctor_slug`,`slot_start`);--> statement-breakpoint
CREATE INDEX `blocked_times_doctor_start_idx` ON `blocked_times` (`doctor_slug`,`start_local`);--> statement-breakpoint
CREATE INDEX `doctor_profiles_specialty_idx` ON `doctor_profiles` (`specialty`);--> statement-breakpoint
CREATE INDEX `doctor_profiles_location_idx` ON `doctor_profiles` (`location`);--> statement-breakpoint
CREATE INDEX `notifications_user_idx` ON `notifications` (`user_id`,`read_at`);