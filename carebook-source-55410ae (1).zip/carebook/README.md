# Carebook — Doctor Appointment Booking

Carebook is a responsive full-stack appointment-booking demo built with React, TypeScript, Vite, Express, tRPC, Drizzle ORM and managed MySQL. The interface uses a calm editorial healthcare style. **All built-in doctor listings are fictional sample profiles. The project does not seed patient records.**

## Included

- Patient profile setup, doctor search and filters, profile/availability pages, appointment requests, detail/status pages, patient dashboard, cancellation and in-app updates.
- Doctor profile registration, admin-review gate, weekly hours, slot duration, blocked-off times, request queue, approve/reject decisions and patient booking notes.
- Admin workspace for account status, doctor verification, specialties, cancellation policy and appointment activity.
- Real Manus OAuth session flow with backend authorization by role. Patient and doctor roles are mutually exclusive per account; admin remains server-controlled. No pretend signed-in demo user or hard-coded credential.
- MySQL-backed application records. Clinic-local appointment labels are stored alongside UTC instants, an IANA timezone snapshot, and start/end offset-minute snapshots, so a repeated fall-back wall time remains distinguishable. Doctor-row locks plus UTC interval checks serialize overlapping booking, schedule and blocked-time changes; a unique doctor+wall-slot key provides an additional same-start guard. Appointment confirmations and decisions are stored as in-app notifications.

Outbound email/SMS delivery is not configured. Appointment confirmations and status updates are currently in-app notifications.

## Run locally

Requirements: Node.js 22, pnpm 10.18.0 and a MySQL-compatible database. Use a **separate development database** for local work. Managed Preview and published deployments share their managed database, so development writes affect that same application data.

```bash
cp .env.example .env
pnpm install
```

Set these local values in `.env`:

- `DATABASE_URL`: MySQL-compatible DSN for the Carebook development database.
- `MANUS_PROJECT_ID`, `MANUS_JWT_SECRET`, `MANUS_OAUTH_PORTAL_URL`, `MANUS_OAUTH_API_URL`: values supplied by the Manus project runtime. Local login requires valid values and an accepted OAuth callback URL.
- `PORT`: defaults to `3000`.

Apply the additive Drizzle schema and populate the fictional provider directory:

```bash
pnpm db:push
pnpm db:seed
```

`pnpm db:seed` is idempotent. It creates four fictional doctor profiles, example weekday availability, specialties, and the default 24-hour cancellation cutoff. It never creates patient rows.

Start the full-stack development server:

```bash
pnpm dev
```

Open `http://localhost:3000`. If valid OAuth values are unavailable, the UI remains signed out and does not invent a session. Admin access comes from the trusted `users.role` field; a user cannot self-assign admin. Patient and doctor onboarding atomically assigns at most one application role to an account. Newly registered doctor profiles remain hidden from search until an admin verifies them; material profile edits return the profile to review, and an outdated admin review action is rejected.

## Project commands

```bash
pnpm check      # TypeScript diagnostics
pnpm test       # Vitest suite
pnpm build      # Build client assets and Express server bundle
pnpm start      # Run the production bundle
```

## Product and data notes

- Patient and doctor features are gated both in the UI and backend procedures.
- Appointment requests reserve the chosen interval while pending. Approval keeps the reservation; rejection/cancellation releases it. Clinic-row locks and UTC interval checks prevent races between overlapping start times; MySQL uniqueness is an additional exact-start guard. Approval/rejection/cancellation are serialized per clinic and appointment.
- Pending requests may always be cancelled. The default approved-visit cutoff is 24 hours, configurable by an admin from 0 to 720 hours.
- Availability is defined in clinic-local time. Each appointment also stores canonical UTC start/end instants, an IANA timezone snapshot, and exact UTC offset-minute snapshots, so calendar ordering, cancellation cutoffs, DST transitions and fall-back displays remain unambiguous. Future dates of birth and impossible calendar dates are rejected. Appointments are not payments; no payment details are collected.
- A patient's optional profile medical notes remain private to the patient; the doctor sees only the note the patient chooses to include on an appointment request.
- Sample profiles are fictional and illustrative, not medical advice. No real clinician or patient data is included.
