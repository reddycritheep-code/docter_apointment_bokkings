import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as carebook from "./carebookDb";

async function run<T>(operation: () => Promise<T>): Promise<T> {
  try { return await operation(); }
  catch (error) {
    if (error instanceof TRPCError) throw error;
    const message = error instanceof Error ? error.message : "The request could not be completed.";
    throw new TRPCError({ code: "BAD_REQUEST", message });
  }
}

const patientProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  const account = await carebook.getAccount(ctx.user.id);
  if (account.role !== "patient" || !account.profile || !account.profile.active) {
    throw new TRPCError({ code: "FORBIDDEN", message: "A patient profile is required for this action." });
  }
  return next();
});

const doctorProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  const account = await carebook.getAccount(ctx.user.id);
  if (account.role !== "doctor" || !account.profile || !account.profile.active) {
    throw new TRPCError({ code: "FORBIDDEN", message: "An active doctor profile is required for this action." });
  }
  return next();
});

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => {
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}, "Choose a valid calendar date.");
const dateOfBirth = z.string().optional().refine(value => {
  if (value === undefined || value === "") return true;
  return isoDate.safeParse(value).success && value <= new Date().toISOString().slice(0, 10);
}, "Enter a real date of birth that is not in the future.");
const localDateTime = z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, "Use a local date and time in YYYY-MM-DDTHH:mm format.").refine(value => {
  const parsed = Date.parse(`${value}:00Z`);
  return Number.isFinite(parsed) && new Date(parsed).toISOString().slice(0, 16) === value;
}, "Choose a valid local date and time.");

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie("webdev_app_session", { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  account: router({
    profile: protectedProcedure.query(({ ctx }) => run(() => carebook.getAccount(ctx.user.id))),
    registerPatient: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(100), phone: z.string().trim().max(40).optional(), dateOfBirth, medicalNotes: z.string().max(2000).optional() })).mutation(({ ctx, input }) => run(() => carebook.savePatientProfile(ctx.user.id, input))),
    registerDoctor: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(140), specialty: z.string().trim().min(2).max(100), qualifications: z.string().trim().min(3).max(255), experienceYears: z.number().int().min(0).max(80), languages: z.string().trim().min(2).max(255), clinicName: z.string().trim().min(2).max(160), location: z.string().trim().min(2).max(160), consultationTypes: z.array(z.enum(["in_person", "online"])).min(1).max(2).refine(value => new Set(value).size === value.length, "Choose each consultation type only once."), fee: z.number().int().min(0).max(5000), bio: z.string().max(1000).optional(), timezone: z.string().min(3).max(64).refine(value => { try { new Intl.DateTimeFormat("en-US", { timeZone: value }); return true; } catch { return false; } }, "Use a valid clinic time zone.") })).mutation(({ ctx, input }) => run(() => carebook.saveDoctorProfile(ctx.user.id, input))),
  }),
  doctors: router({
    list: publicProcedure.input(z.object({ specialty: z.string().optional(), location: z.string().trim().max(100).optional(), consultationType: z.enum(["in_person", "online"]).optional(), availableDate: isoDate.optional() }).optional()).query(({ input }) => run(() => carebook.listDoctors(input ?? {}))),
    detail: publicProcedure.input(z.object({ slug: z.string().min(1).max(80) })).query(({ input }) => run(() => carebook.getDoctor(input.slug))),
    slots: publicProcedure.input(z.object({ slug: z.string().min(1).max(80), date: isoDate })).query(({ input }) => run(() => carebook.availableSlots(input.slug, input.date))),
    specialties: publicProcedure.query(() => run(() => carebook.listSpecialties())),
  }),
  patient: router({
    dashboard: patientProcedure.query(({ ctx }) => run(() => carebook.patientDashboard(ctx.user.id))),
    requestAppointment: patientProcedure.input(z.object({ doctorSlug: z.string().min(1).max(80), slotStart: localDateTime, mode: z.enum(["in_person", "online"]), reason: z.string().max(1000).optional() })).mutation(({ ctx, input }) => run(() => carebook.requestAppointment(ctx.user.id, input))),
    cancelAppointment: patientProcedure.input(z.object({ id: z.string().min(1).max(40) })).mutation(({ ctx, input }) => run(() => carebook.cancelAppointment(ctx.user.id, input.id))),
    notifications: patientProcedure.query(({ ctx }) => run(() => carebook.listNotifications(ctx.user.id))),
    markNotificationRead: patientProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => run(() => carebook.markNotificationRead(ctx.user.id, input.id))),
  }),
  doctor: router({
    dashboard: doctorProcedure.query(({ ctx }) => run(() => carebook.doctorDashboard(ctx.user.id))),
    slots: doctorProcedure.query(({ ctx }) => run(() => carebook.doctorSchedule(ctx.user.id))),
    updateSchedule: doctorProcedure.input(z.object({ weekday: z.number().int().min(0).max(6), startTime: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/), endTime: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/), slotMinutes: z.number().int().min(15).max(120), active: z.boolean() }).refine(input => input.endTime > input.startTime, { message: "The end time must be after the start time." })).mutation(({ ctx, input }) => run(() => carebook.updateSchedule(ctx.user.id, input))),
    blockTime: doctorProcedure.input(z.object({ startLocal: localDateTime, endLocal: localDateTime, note: z.string().max(160).optional() }).refine(input => input.endLocal > input.startLocal, { message: "The end time must be after the start time." })).mutation(({ ctx, input }) => run(() => carebook.addBlockedTime(ctx.user.id, input))),
    removeBlockedTime: doctorProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => run(() => carebook.removeBlockedTime(ctx.user.id, input.id))),
    decide: doctorProcedure.input(z.object({ id: z.string().min(1).max(40), action: z.enum(["approve", "reject"]), message: z.string().max(1000).optional() })).mutation(({ ctx, input }) => run(() => carebook.decideAppointment(ctx.user.id, input))),
    notifications: doctorProcedure.query(({ ctx }) => run(() => carebook.listNotifications(ctx.user.id))),
    markNotificationRead: doctorProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => run(() => carebook.markNotificationRead(ctx.user.id, input.id))),
  }),
  appointments: router({
    detail: protectedProcedure.input(z.object({ id: z.string().min(1).max(40) })).query(({ ctx, input }) => run(async () => {
      const appointment = await carebook.getAppointment(input.id);
      if (!appointment) throw new TRPCError({ code: "NOT_FOUND", message: "Appointment not found." });
      const account = await carebook.getAccount(ctx.user.id);
      const profile = account.profile as { slug?: string; active?: boolean } | null;
      const isDoctor = account.role === "doctor" && profile?.active === true && profile.slug === appointment.doctorSlug;
      const isPatient = account.role === "patient" && profile?.active === true && appointment.patientUserId === ctx.user.id;
      if (!isPatient && !isDoctor && account.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "You do not have access to this appointment." });
      return appointment;
    })),
  }),
  admin: router({
    overview: adminProcedure.query(() => run(() => carebook.adminOverview())),
    setDoctorStatus: adminProcedure.input(z.object({ slug: z.string().min(1).max(80), verified: z.boolean().optional(), active: z.boolean().optional(), expectedProfileRevision: z.number().int().min(0).optional() }).refine(input => input.verified === undefined || input.expectedProfileRevision !== undefined, "Refresh the doctor profile before verifying it.")).mutation(({ input }) => run(() => carebook.adminSetDoctor(input))),
    setUserActive: adminProcedure.input(z.object({ userId: z.number().int().positive(), active: z.boolean() })).mutation(({ input }) => run(() => carebook.adminSetUserActive(input.userId, input.active))),
    setSpecialty: adminProcedure.input(z.object({ name: z.string().trim().min(2).max(100), active: z.boolean() })).mutation(({ input }) => run(() => carebook.adminSetSpecialty(input.name, input.active))),
    setCancellationHours: adminProcedure.input(z.object({ hours: z.number().int().min(0).max(720) })).mutation(({ input }) => run(() => carebook.adminSetCancellationHours(input.hours))),
  }),
});

export type AppRouter = typeof appRouter;
