import { describe, expect, it } from "vitest";
import { clinicDateInputValue, clinicLocalToUtc, formatClinicTime, utcOffsetMinutesAt, utcToClinicLocal } from "../shared/timezone";

describe("clinic timezone conversion", () => {
  it("converts a clinic wall time to a canonical UTC instant", () => {
    expect(clinicLocalToUtc("2026-10-12T09:00", "America/Los_Angeles").toISOString())
      .toBe("2026-10-12T16:00:00.000Z");
  });

  it("rejects impossible calendar dates and invalid clock times", () => {
    expect(() => clinicLocalToUtc("2026-02-30T09:00", "UTC")).toThrow("valid calendar date");
    expect(() => clinicLocalToUtc("2026-10-12T24:00", "UTC")).toThrow("valid calendar date");
  });

  it("rejects clinic times skipped by the spring daylight-saving transition", () => {
    expect(() => clinicLocalToUtc("2026-03-08T02:30", "America/Los_Angeles"))
      .toThrow("daylight-saving time change");
  });

  it("chooses the earlier occurrence for a repeated fall-back wall time", () => {
    expect(clinicLocalToUtc("2026-11-01T01:30", "America/Los_Angeles").toISOString())
      .toBe("2026-11-01T08:30:00.000Z");
  });

  it("converts UTC instants back to the chosen clinic timezone and labels the offset", () => {
    const laterRepeatedHour = "2026-11-01T09:30:00.000Z";
    expect(utcToClinicLocal(laterRepeatedHour, "America/Los_Angeles")).toBe("2026-11-01T01:30");
    expect(formatClinicTime(laterRepeatedHour, "America/Los_Angeles")).toContain("PST");
  });

  it("stores distinct offsets for a fall-back appointment whose start and end wall clocks match", () => {
    const start = "2026-11-01T08:00:00.000Z";
    const end = "2026-11-01T09:00:00.000Z";
    expect(utcToClinicLocal(start, "America/Los_Angeles")).toBe("2026-11-01T01:00");
    expect(utcToClinicLocal(end, "America/Los_Angeles")).toBe("2026-11-01T01:00");
    expect(utcOffsetMinutesAt(start, "America/Los_Angeles")).toBe(-420);
    expect(utcOffsetMinutesAt(end, "America/Los_Angeles")).toBe(-480);
  });

  it("calculates appointment dates from the clinic calendar, not the browser/UTC calendar", () => {
    const now = new Date("2026-10-10T03:30:00.000Z");
    expect(clinicDateInputValue(1, "America/Los_Angeles", now)).toBe("2026-10-10");
    expect(clinicDateInputValue(1, "UTC", now)).toBe("2026-10-11");
  });
});
