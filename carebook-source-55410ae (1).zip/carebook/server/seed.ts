import "dotenv/config";
import mysql from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import { doctorProfiles, doctorSchedules, siteSettings, specialties } from "../drizzle/schema";

const samples = [
  { slug: "dr-maya-bennett", name: "Dr. Maya Bennett", specialty: "Family Medicine", qualifications: "MD, University of Washington", experienceYears: 12, languages: "English, Spanish", clinicName: "Willow Family Health", location: "Portland, OR", consultationTypes: '["in_person","online"]', fee: 95, bio: "Thoughtful primary care for every chapter of life, with a focus on prevention and practical wellbeing.", timezone: "America/Los_Angeles" },
  { slug: "dr-james-okafor", name: "Dr. James Okafor", specialty: "Cardiology", qualifications: "MD, FACC", experienceYears: 15, languages: "English, French", clinicName: "Northstar Heart Clinic", location: "Seattle, WA", consultationTypes: '["in_person","online"]', fee: 145, bio: "Evidence-led heart care delivered with time to listen and a plan you can understand.", timezone: "America/Los_Angeles" },
  { slug: "dr-lina-chen", name: "Dr. Lina Chen", specialty: "Dermatology", qualifications: "MD, FAAD", experienceYears: 9, languages: "English, Mandarin", clinicName: "Sage Dermatology Studio", location: "San Francisco, CA", consultationTypes: '["in_person"]', fee: 120, bio: "Patient-first skin health, from everyday concerns to long-term treatment plans.", timezone: "America/Los_Angeles" },
  { slug: "dr-sofia-ramirez", name: "Dr. Sofia Ramirez", specialty: "Pediatrics", qualifications: "MD, FAAP", experienceYears: 11, languages: "English, Spanish", clinicName: "Little Harbor Pediatrics", location: "Austin, TX", consultationTypes: '["in_person","online"]', fee: 105, bio: "Warm, collaborative care for children and the people who care for them.", timezone: "America/Chicago" },
];

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required to seed the managed database.");
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);
  try {
    for (const doctor of samples) {
      await db.insert(doctorProfiles).values({ ...doctor, verified: true, active: true, isSample: true }).onDuplicateKeyUpdate({ set: { ...doctor, verified: true, active: true, isSample: true } });
      for (const weekday of [1, 2, 3, 4, 5]) {
        await db.insert(doctorSchedules).values({ doctorSlug: doctor.slug, weekday, startTime: "09:00", endTime: "16:00", slotMinutes: 30, active: true }).onDuplicateKeyUpdate({ set: { startTime: "09:00", endTime: "16:00", slotMinutes: 30, active: true } });
      }
      await db.insert(doctorSchedules).values({ doctorSlug: doctor.slug, weekday: 6, startTime: "10:00", endTime: "13:00", slotMinutes: 30, active: true }).onDuplicateKeyUpdate({ set: { startTime: "10:00", endTime: "13:00", slotMinutes: 30, active: true } });
    }
    for (const name of ["Cardiology", "Dermatology", "Family Medicine", "Pediatrics", "Psychology"]) {
      await db.insert(specialties).values({ name, active: true }).onDuplicateKeyUpdate({ set: { active: true } });
    }
    const existingSetting = await db.select().from(siteSettings).where((await import("drizzle-orm")).eq(siteSettings.key, "cancellation_hours")).limit(1);
    if (!existingSetting.length) await db.insert(siteSettings).values({ key: "cancellation_hours", value: "24" });
    console.log("Seeded 4 fictional doctor profiles and weekly availability. No patient records were created.");
  } finally {
    await connection.end();
  }
}

main().catch(error => { console.error("Seed failed:", error instanceof Error ? error.message : error); process.exit(1); });
