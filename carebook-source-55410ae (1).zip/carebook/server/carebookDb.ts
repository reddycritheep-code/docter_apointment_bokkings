import { and, asc, desc, eq, inArray, like, or } from "drizzle-orm";
import { nanoid } from "nanoid";
import type { ConsultationMode, DoctorSummary, PublicDoctorSummary } from "../shared/carebook";
import { addUtcMinutes, clinicLocalToUtcIso, utcOffsetMinutesAt, utcToClinicLocal } from "../shared/timezone";
import {
  appointments,
  blockedTimes,
  doctorProfiles,
  doctorSchedules,
  notifications,
  patientProfiles,
  siteSettings,
  slotReservations,
  specialties,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";

const SAMPLE_DOCTORS = [
  { slug: "dr-maya-bennett", userId: null, name: "Dr. Maya Bennett", specialty: "Family Medicine", qualifications: "MD, University of Washington", experienceYears: 12, languages: "English, Spanish", clinicName: "Willow Family Health", location: "Portland, OR", consultationTypes: '["in_person","online"]', fee: 95, bio: "Thoughtful primary care for every chapter of life, with a focus on prevention and practical wellbeing.", timezone: "America/Los_Angeles", verified: true, active: true, isSample: true },
  { slug: "dr-james-okafor", userId: null, name: "Dr. James Okafor", specialty: "Cardiology", qualifications: "MD, FACC", experienceYears: 15, languages: "English, French", clinicName: "Northstar Heart Clinic", location: "Seattle, WA", consultationTypes: '["in_person","online"]', fee: 145, bio: "Evidence-led heart care delivered with time to listen and a plan you can understand.", timezone: "America/Los_Angeles", verified: true, active: true, isSample: true },
  { slug: "dr-lina-chen", userId: null, name: "Dr. Lina Chen", specialty: "Dermatology", qualifications: "MD, FAAD", experienceYears: 9, languages: "English, Mandarin", clinicName: "Sage Dermatology Studio", location: "San Francisco, CA", consultationTypes: '["in_person"]', fee: 120, bio: "Patient-first skin health, from everyday concerns to long-term treatment plans.", timezone: "America/Los_Angeles", verified: true, active: true, isSample: true },
  { slug: "dr-sofia-ramirez", userId: null, name: "Dr. Sofia Ramirez", specialty: "Pediatrics", qualifications: "MD, FAAP", experienceYears: 11, languages: "English, Spanish", clinicName: "Little Harbor Pediatrics", location: "Austin, TX", consultationTypes: '["in_person","online"]', fee: 105, bio: "Warm, collaborative care for children and the people who care for them.", timezone: "America/Chicago", verified: true, active: true, isSample: true },
];

function parseTypes(raw: string): ConsultationMode[] {
  try {
    const parsed: unknown = JSON.parse(raw);
    const modes = Array.isArray(parsed) ? parsed.filter((value): value is ConsultationMode => value === "in_person" || value === "online") : [];
    return modes.length ? modes : ["in_person"];
  } catch { return ["in_person"]; }
}

function safeDoctor(row: typeof doctorProfiles.$inferSelect): DoctorSummary {
  return {
    slug: row.slug, name: row.name, specialty: row.specialty, qualifications: row.qualifications,
    experienceYears: row.experienceYears, languages: row.languages.split(",").map(item => item.trim()).filter(Boolean),
    clinicName: row.clinicName, location: row.location, consultationTypes: parseTypes(row.consultationTypes),
    fee: row.fee, bio: row.bio, timezone: row.timezone, verified: row.verified, active: row.active,
    isSample: row.isSample, profileRevision: row.profileRevision,
  };
}

function safeSample(doctor: (typeof SAMPLE_DOCTORS)[number]): DoctorSummary {
  return {
    slug: doctor.slug, name: doctor.name, specialty: doctor.specialty, qualifications: doctor.qualifications,
    experienceYears: doctor.experienceYears, languages: doctor.languages.split(",").map(item => item.trim()).filter(Boolean),
    clinicName: doctor.clinicName, location: doctor.location, consultationTypes: parseTypes(doctor.consultationTypes),
    fee: doctor.fee, bio: doctor.bio, timezone: doctor.timezone, verified: doctor.verified, active: doctor.active,
    isSample: doctor.isSample, profileRevision: 0,
  };
}

function publicDoctor(doctor: DoctorSummary): PublicDoctorSummary {
  const { verified: _verified, active: _active, profileRevision: _profileRevision, ...publicFields } = doctor;
  return publicFields;
}

function weekdayFor(date: string): number {
  return new Date(`${date}T00:00:00Z`).getUTCDay();
}

function appointmentStartUtc(row: { slotStart: string; slotStartUtc: string | null; timeZone: string | null }, fallbackZone: string): string {
  return row.slotStartUtc || clinicLocalToUtcIso(row.slotStart, row.timeZone || fallbackZone);
}

function appointmentEndUtc(row: { slotEnd: string; slotEndUtc: string | null; timeZone: string | null }, fallbackZone: string): string {
  return row.slotEndUtc || clinicLocalToUtcIso(row.slotEnd, row.timeZone || fallbackZone);
}

function overlaps(startA: string, endA: string, startB: string, endB: string): boolean {
  const startAMs = Date.parse(startA);
  const endAMs = Date.parse(endA);
  const startBMs = Date.parse(startB);
  const endBMs = Date.parse(endB);
  return Number.isFinite(startAMs) && Number.isFinite(endAMs) && Number.isFinite(startBMs) && Number.isFinite(endBMs) && startAMs < endBMs && endAMs > startBMs;
}

async function reservationIntervals(db: any, doctor: typeof doctorProfiles.$inferSelect, lock = false): Promise<Array<{ startUtc: string; endUtc: string }>> {
  let query = db.select({
    slotStart: appointments.slotStart,
    slotEnd: appointments.slotEnd,
    slotStartUtc: appointments.slotStartUtc,
    slotEndUtc: appointments.slotEndUtc,
    timeZone: appointments.timeZone,
  }).from(slotReservations)
    .innerJoin(appointments, eq(slotReservations.appointmentId, appointments.id))
    .where(and(eq(slotReservations.doctorSlug, doctor.slug), inArray(appointments.status, ["pending", "approved"])));
  if (lock) query = query.for("update");
  const rows = await query;
  return rows.map((row: { slotStart: string; slotEnd: string; slotStartUtc: string | null; slotEndUtc: string | null; timeZone: string | null }) => ({
    startUtc: appointmentStartUtc(row, doctor.timezone),
    endUtc: appointmentEndUtc(row, doctor.timezone),
  }));
}

async function slotsFor(db: any, doctor: typeof doctorProfiles.$inferSelect, date: string, lockReservations = false) {
  const scheduleRows = await db.select().from(doctorSchedules).where(and(eq(doctorSchedules.doctorSlug, doctor.slug), eq(doctorSchedules.weekday, weekdayFor(date)), eq(doctorSchedules.active, true)));
  if (!scheduleRows.length) return [] as string[];
  const reserved = await reservationIntervals(db, doctor, lockReservations);
  const blocks = await db.select().from(blockedTimes).where(eq(blockedTimes.doctorSlug, doctor.slug));
  const blockIntervals = blocks.map((block: typeof blockedTimes.$inferSelect) => ({
    startUtc: block.startUtc || clinicLocalToUtcIso(block.startLocal, block.timeZone || doctor.timezone),
    endUtc: block.endUtc || clinicLocalToUtcIso(block.endLocal, block.timeZone || doctor.timezone),
  }));
  const now = Date.now();
  const result: string[] = [];
  for (const schedule of scheduleRows) {
    const [startHour, startMinute] = schedule.startTime.split(":").map(Number);
    const [endHour, endMinute] = schedule.endTime.split(":").map(Number);
    let cursor = startHour * 60 + startMinute;
    const end = endHour * 60 + endMinute;
    while (cursor + schedule.slotMinutes <= end) {
      const startText = `${date}T${String(Math.floor(cursor / 60)).padStart(2, "0")}:${String(cursor % 60).padStart(2, "0")}`;
      let startUtc: string;
      try {
        startUtc = clinicLocalToUtcIso(startText, doctor.timezone);
      } catch (error) {
        if (error instanceof Error && error.message.includes("daylight-saving time change")) {
          cursor += schedule.slotMinutes;
          continue;
        }
        throw error;
      }
      const endUtc = addUtcMinutes(startUtc, schedule.slotMinutes).toISOString();
      const endText = utcToClinicLocal(endUtc, doctor.timezone);
      if (endText.slice(0, 10) !== date || endText.slice(11) > schedule.endTime) {
        cursor += schedule.slotMinutes;
        continue;
      }
      const isBlocked = blockIntervals.some((block: { startUtc: string; endUtc: string }) => overlaps(startUtc, endUtc, block.startUtc, block.endUtc));
      const isReserved = reserved.some(interval => overlaps(startUtc, endUtc, interval.startUtc, interval.endUtc));
      if (Date.parse(startUtc) > now && !isReserved && !isBlocked) result.push(startText);
      cursor += schedule.slotMinutes;
    }
  }
  return result.sort();
}

export async function getAccount(userId: number) {
  const db = await getDb();
  if (!db) return { role: null as null, userId, profile: null };
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return { role: null as null, userId, profile: null };
  if (user.role === "admin") return { role: "admin" as const, userId, profile: { name: user.name, email: user.email } };
  if (user.role === "doctor") {
    const [doctor] = await db.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).limit(1);
    return { role: "doctor" as const, userId, profile: doctor ? safeDoctor(doctor) : null };
  }
  if (user.role === "patient") {
    const [patient] = await db.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1);
    return { role: "patient" as const, userId, profile: patient ?? null };
  }
  return { role: null as null, userId, profile: null };
}

export async function savePatientProfile(userId: number, input: { name?: string; phone?: string; dateOfBirth?: string; medicalNotes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [user] = await tx.select().from(users).where(eq(users.id, userId)).for("update").limit(1);
    if (!user) throw new Error("Your signed-in account could not be found.");
    if (user.role === "admin" || user.role === "doctor") throw new Error("This account is not a patient account. Use a separate account for patient access.");
    const [doctor] = await tx.select({ slug: doctorProfiles.slug }).from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).limit(1);
    if (doctor) throw new Error("This account already has a doctor profile. Patient and doctor roles must use separate accounts.");
    await tx.update(users).set({ role: "patient", ...(input.name ? { name: input.name } : {}) }).where(eq(users.id, userId));
    await tx.insert(patientProfiles).values({ userId, phone: input.phone ?? null, dateOfBirth: input.dateOfBirth || null, medicalNotes: input.medicalNotes ?? null }).onDuplicateKeyUpdate({ set: { phone: input.phone ?? null, dateOfBirth: input.dateOfBirth || null, medicalNotes: input.medicalNotes ?? null } });
    const [profile] = await tx.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1);
    return profile;
  });
}

export async function saveDoctorProfile(userId: number, input: { name: string; specialty: string; qualifications: string; experienceYears: number; languages: string; clinicName: string; location: string; consultationTypes: string[]; fee: number; bio?: string; timezone: string }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  const slug = `doctor-${userId}`;
  return db.transaction(async (tx: any) => {
    const [user] = await tx.select().from(users).where(eq(users.id, userId)).for("update").limit(1);
    if (!user) throw new Error("Your signed-in account could not be found.");
    if (user.role === "admin" || user.role === "patient") throw new Error("This account is not a doctor account. Use a separate account for doctor access.");
    const [patient] = await tx.select({ id: patientProfiles.id }).from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1);
    if (patient) throw new Error("This account already has a patient profile. Patient and doctor roles must use separate accounts.");
    const [existing] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).for("update").limit(1);
    const consultationTypes = JSON.stringify([...input.consultationTypes].sort());
    const changed = Boolean(existing && (
      existing.name !== input.name || existing.specialty !== input.specialty || existing.qualifications !== input.qualifications ||
      existing.experienceYears !== input.experienceYears || existing.languages !== input.languages || existing.clinicName !== input.clinicName ||
      existing.location !== input.location || existing.consultationTypes !== consultationTypes || existing.fee !== input.fee ||
      existing.bio !== (input.bio ?? null) || existing.timezone !== input.timezone
    ));
    const profileRevision = (existing?.profileRevision ?? 0) + (changed ? 1 : 0);
    await tx.update(users).set({ role: "doctor", name: input.name }).where(eq(users.id, userId));
    await tx.insert(doctorProfiles).values({ slug, userId, name: input.name, specialty: input.specialty, qualifications: input.qualifications, experienceYears: input.experienceYears, languages: input.languages, clinicName: input.clinicName, location: input.location, consultationTypes, fee: input.fee, bio: input.bio ?? null, timezone: input.timezone, verified: false, active: true, isSample: false, profileRevision }).onDuplicateKeyUpdate({ set: { name: input.name, specialty: input.specialty, qualifications: input.qualifications, experienceYears: input.experienceYears, languages: input.languages, clinicName: input.clinicName, location: input.location, consultationTypes, fee: input.fee, bio: input.bio ?? null, timezone: input.timezone, verified: changed ? false : (existing?.verified ?? false), profileRevision } });
    const currentSchedule = await tx.select().from(doctorSchedules).where(eq(doctorSchedules.doctorSlug, slug)).limit(1);
    if (!currentSchedule.length) {
      for (const weekday of [1, 2, 3, 4, 5]) await tx.insert(doctorSchedules).values({ doctorSlug: slug, weekday, startTime: "09:00", endTime: "17:00", slotMinutes: 30, active: true });
    }
    const [profile] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.slug, slug)).limit(1);
    return profile ? safeDoctor(profile) : null;
  });
}

export async function listDoctors(filters: { specialty?: string; location?: string; consultationType?: ConsultationMode; availableDate?: string }): Promise<PublicDoctorSummary[]> {
  const db = await getDb();
  if (!db) return SAMPLE_DOCTORS.filter(doctor => (!filters.specialty || doctor.specialty === filters.specialty) && (!filters.location || doctor.location.toLowerCase().includes(filters.location.toLowerCase())) && (!filters.consultationType || parseTypes(doctor.consultationTypes).includes(filters.consultationType)) && (!filters.availableDate || new Date(`${filters.availableDate}T00:00:00Z`).getUTCDay() !== 0)).map(doctor => publicDoctor(safeSample(doctor)));
  const conditions = [eq(doctorProfiles.active, true), eq(doctorProfiles.verified, true)];
  if (filters.specialty) conditions.push(eq(doctorProfiles.specialty, filters.specialty));
  if (filters.location) conditions.push(or(like(doctorProfiles.location, `%${filters.location}%`), like(doctorProfiles.clinicName, `%${filters.location}%`))!);
  let rows = await db.select().from(doctorProfiles).where(and(...conditions)).orderBy(asc(doctorProfiles.name));
  if (filters.availableDate) {
    const withAvailability = await Promise.all(rows.map(async row => ({ row, available: (await slotsFor(db, row, filters.availableDate!)).length > 0 })));
    rows = withAvailability.filter(item => item.available).map(item => item.row);
  }
  return rows.map(row => publicDoctor(safeDoctor(row))).filter(doctor => !filters.consultationType || doctor.consultationTypes.includes(filters.consultationType));
}

export async function getDoctor(slug: string): Promise<PublicDoctorSummary | null> {
  const db = await getDb();
  if (!db) {
    const doctor = SAMPLE_DOCTORS.find(item => item.slug === slug);
    return doctor ? publicDoctor(safeSample(doctor)) : null;
  }
  const [doctor] = await db.select().from(doctorProfiles).where(and(eq(doctorProfiles.slug, slug), eq(doctorProfiles.active, true), eq(doctorProfiles.verified, true))).limit(1);
  return doctor ? publicDoctor(safeDoctor(doctor)) : null;
}

export async function availableSlots(slug: string, date: string) {
  const db = await getDb();
  if (!db) return [];
  const [doctor] = await db.select().from(doctorProfiles).where(and(eq(doctorProfiles.slug, slug), eq(doctorProfiles.active, true), eq(doctorProfiles.verified, true))).limit(1);
  return doctor ? slotsFor(db, doctor, date) : [];
}

export async function listSpecialties() {
  const db = await getDb();
  if (!db) return ["Cardiology", "Dermatology", "Family Medicine", "Pediatrics"];
  const rows = await db.select().from(specialties).where(eq(specialties.active, true)).orderBy(asc(specialties.name));
  return rows.map(row => row.name);
}

async function createNotification(db: any, userId: number | null | undefined, appointmentId: string, title: string, body: string) {
  if (!userId) return;
  await db.insert(notifications).values({ userId, appointmentId, title, body });
}

function normalizedAppointment(row: typeof appointments.$inferSelect, fallbackZone: string) {
  const timeZone = row.timeZone || fallbackZone;
  const slotStartUtc = appointmentStartUtc(row, timeZone);
  const slotEndUtc = appointmentEndUtc(row, timeZone);
  return {
    ...row,
    timeZone,
    slotStartUtc,
    slotEndUtc,
    slotStartOffsetMinutes: row.slotStartOffsetMinutes ?? utcOffsetMinutesAt(slotStartUtc, timeZone),
    slotEndOffsetMinutes: row.slotEndOffsetMinutes ?? utcOffsetMinutesAt(slotEndUtc, timeZone),
  };
}

export async function requestAppointment(userId: number, input: { doctorSlug: string; slotStart: string; mode: "in_person" | "online"; reason?: string }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  const appointmentId = nanoid(18);
  return db.transaction(async (tx: any) => {
    const [patient] = await tx.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).for("update").limit(1);
    if (!patient || !patient.active) throw new Error("An active patient profile is required to request an appointment.");
    // One lock per clinic serializes all slot requests, including overlapping
    // appointments with different start times and variable durations.
    const [doctor] = await tx.select().from(doctorProfiles).where(and(eq(doctorProfiles.slug, input.doctorSlug), eq(doctorProfiles.active, true), eq(doctorProfiles.verified, true))).for("update").limit(1);
    if (!doctor) throw new Error("This doctor is not currently available for bookings.");
    if (!parseTypes(doctor.consultationTypes).includes(input.mode)) throw new Error("This doctor does not offer that consultation type.");
    const slots = await slotsFor(tx, doctor, input.slotStart.slice(0, 10), true);
    if (!slots.includes(input.slotStart)) throw new Error("That time is no longer available. Choose another slot.");
    const schedule = await tx.select().from(doctorSchedules).where(and(eq(doctorSchedules.doctorSlug, doctor.slug), eq(doctorSchedules.weekday, weekdayFor(input.slotStart.slice(0, 10))), eq(doctorSchedules.active, true))).limit(1);
    const minutes = schedule[0]?.slotMinutes ?? 30;
    const slotStartUtc = clinicLocalToUtcIso(input.slotStart, doctor.timezone);
    const slotEndUtc = addUtcMinutes(slotStartUtc, minutes).toISOString();
    const slotEnd = utcToClinicLocal(slotEndUtc, doctor.timezone);
    await tx.insert(appointments).values({ id: appointmentId, patientUserId: userId, doctorSlug: doctor.slug, slotStart: input.slotStart, slotEnd, slotStartUtc, slotEndUtc, slotStartOffsetMinutes: utcOffsetMinutesAt(slotStartUtc, doctor.timezone), slotEndOffsetMinutes: utcOffsetMinutesAt(slotEndUtc, doctor.timezone), timeZone: doctor.timezone, mode: input.mode, reason: input.reason?.trim() || null, status: "pending" });
    // The doctor-row lock serializes interval checks; the unique doctor+wall-slot
    // key remains a final constraint for an identical clinic-local start time.
    await tx.insert(slotReservations).values({ doctorSlug: doctor.slug, slotStart: input.slotStart, appointmentId });
    await createNotification(tx, userId, appointmentId, "Request sent", `Your appointment request with ${doctor.name} is pending.`);
    await createNotification(tx, doctor.userId, appointmentId, "New appointment request", `A patient requested ${input.slotStart.replace("T", " ")} (${doctor.timezone}).`);
    return { id: appointmentId, status: "pending" as const };
  });
}

export async function patientDashboard(userId: number) {
  const db = await getDb();
  if (!db) return { profile: null, appointments: [] };
  const [profile] = await db.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1);
  const rows = await db.select({ appointment: appointments, doctor: doctorProfiles }).from(appointments).leftJoin(doctorProfiles, eq(appointments.doctorSlug, doctorProfiles.slug)).where(eq(appointments.patientUserId, userId)).orderBy(desc(appointments.slotStartUtc));
  return { profile: profile ?? null, appointments: rows.map(row => ({ ...normalizedAppointment(row.appointment, row.doctor?.timezone ?? "UTC"), doctor: row.doctor ? publicDoctor(safeDoctor(row.doctor)) : null })) };
}

export async function doctorDashboard(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const [doctor] = await db.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).limit(1);
  if (!doctor) return null;
  const rows = await db.select({ appointment: appointments, patient: users }).from(appointments).innerJoin(users, eq(appointments.patientUserId, users.id)).where(eq(appointments.doctorSlug, doctor.slug)).orderBy(desc(appointments.slotStartUtc));
  const schedule = await db.select().from(doctorSchedules).where(eq(doctorSchedules.doctorSlug, doctor.slug)).orderBy(asc(doctorSchedules.weekday));
  const now = Date.now();
  const blocks = (await db.select().from(blockedTimes).where(eq(blockedTimes.doctorSlug, doctor.slug)))
    .map((block: typeof blockedTimes.$inferSelect) => ({ ...block, startUtc: block.startUtc || clinicLocalToUtcIso(block.startLocal, block.timeZone || doctor.timezone), endUtc: block.endUtc || clinicLocalToUtcIso(block.endLocal, block.timeZone || doctor.timezone) }))
    .filter((block: { endUtc: string }) => Date.parse(block.endUtc) >= now)
    .slice(0, 30);
  return { profile: safeDoctor(doctor), appointments: rows.map(row => ({ ...normalizedAppointment(row.appointment, doctor.timezone), patientName: row.patient.name ?? "Patient" })), schedule, blocks };
}

export async function updateSchedule(userId: number, input: { weekday: number; startTime: string; endTime: string; slotMinutes: number; active: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).for("update").limit(1);
    if (!doctor || !doctor.active) throw new Error("An active doctor profile is required to update availability.");
    await tx.insert(doctorSchedules).values({ doctorSlug: doctor.slug, ...input }).onDuplicateKeyUpdate({ set: { startTime: input.startTime, endTime: input.endTime, slotMinutes: input.slotMinutes, active: input.active } });
    return { success: true };
  });
}

export async function addBlockedTime(userId: number, input: { startLocal: string; endLocal: string; note?: string }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).for("update").limit(1);
    if (!doctor || !doctor.active) throw new Error("An active doctor profile is required to update blocked time.");
    const startUtc = clinicLocalToUtcIso(input.startLocal, doctor.timezone);
    const endUtc = clinicLocalToUtcIso(input.endLocal, doctor.timezone);
    if (Date.parse(endUtc) <= Date.parse(startUtc)) throw new Error("The blocked period must end after it starts in clinic time.");
    const reservations = await reservationIntervals(tx, doctor, true);
    if (reservations.some(interval => overlaps(startUtc, endUtc, interval.startUtc, interval.endUtc))) {
      throw new Error("This block overlaps an active appointment. Resolve the appointment before blocking that time.");
    }
    await tx.insert(blockedTimes).values({ doctorSlug: doctor.slug, startLocal: input.startLocal, endLocal: input.endLocal, startUtc, endUtc, timeZone: doctor.timezone, note: input.note ?? null });
    return { success: true };
  });
}

export async function removeBlockedTime(userId: number, blockId: number) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).for("update").limit(1);
    if (!doctor || !doctor.active) throw new Error("An active doctor profile is required to update blocked time.");
    await tx.delete(blockedTimes).where(and(eq(blockedTimes.id, blockId), eq(blockedTimes.doctorSlug, doctor.slug)));
    return { success: true };
  });
}

export async function decideAppointment(userId: number, input: { id: string; action: "approve" | "reject"; message?: string }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).for("update").limit(1);
    if (!doctor || !doctor.active) throw new Error("An active doctor profile is required to decide appointment requests.");
    const [appointment] = await tx.select().from(appointments).where(and(eq(appointments.id, input.id), eq(appointments.doctorSlug, doctor.slug))).for("update").limit(1);
    if (!appointment || appointment.status !== "pending") throw new Error("This request is no longer pending.");
    const status = input.action === "approve" ? "approved" : "rejected";
    await tx.update(appointments).set({ status, decisionMessage: input.action === "reject" ? input.message?.trim() || null : null }).where(eq(appointments.id, appointment.id));
    if (status === "rejected") await tx.delete(slotReservations).where(eq(slotReservations.appointmentId, appointment.id));
    const timeZone = appointment.timeZone || doctor.timezone;
    const localSlot = `${appointment.slotStart.replace("T", " ")} (${timeZone})`;
    await createNotification(tx, appointment.patientUserId, appointment.id, status === "approved" ? "Appointment approved" : "Appointment update", status === "approved" ? `${doctor.name} approved your appointment for ${localSlot}.` : `${doctor.name} could not accept your request.${input.message ? ` ${input.message}` : ""}`);
    return { success: true, status };
  });
}

function hoursUntilUtc(slotStartUtc: string) {
  return (Date.parse(slotStartUtc) - Date.now()) / 3_600_000;
}

export async function cancelAppointment(userId: number, appointmentId: string) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    // Serialize profile activity changes before reading the appointment. An admin
    // deactivation either commits first (and blocks this action) or waits until it ends.
    const [patient] = await tx.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).for("update").limit(1);
    if (!patient || !patient.active) throw new Error("An active patient profile is required to cancel appointments.");
    const [initial] = await tx.select({ doctorSlug: appointments.doctorSlug }).from(appointments).where(and(eq(appointments.id, appointmentId), eq(appointments.patientUserId, userId))).limit(1);
    if (!initial) throw new Error("This appointment cannot be cancelled.");
    // Patient-originated clinic actions lock patient -> clinic -> appointment.
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.slug, initial.doctorSlug)).for("update").limit(1);
    const [appointment] = await tx.select().from(appointments).where(and(eq(appointments.id, appointmentId), eq(appointments.patientUserId, userId))).for("update").limit(1);
    if (!appointment || !["pending", "approved"].includes(appointment.status)) throw new Error("This appointment cannot be cancelled.");
    const timeZone = appointment.timeZone || doctor?.timezone || "UTC";
    const slotStartUtc = appointmentStartUtc(appointment, timeZone);
    if (appointment.status === "approved") {
      const [setting] = await tx.select().from(siteSettings).where(eq(siteSettings.key, "cancellation_hours")).limit(1);
      const cutoff = Number(setting?.value ?? 24);
      if (hoursUntilUtc(slotStartUtc) < cutoff) throw new Error(`Approved appointments must be cancelled at least ${cutoff} hours in advance.`);
    }
    await tx.update(appointments).set({ status: "cancelled" }).where(eq(appointments.id, appointmentId));
    await tx.delete(slotReservations).where(eq(slotReservations.appointmentId, appointmentId));
    await createNotification(tx, doctor?.userId, appointment.id, "Appointment cancelled", `The appointment scheduled for ${appointment.slotStart.replace("T", " ")} (${timeZone}) was cancelled.`);
    return { success: true };
  });
}

export async function getAppointment(appointmentId: string) {
  const db = await getDb();
  if (!db) return null;
  const [row] = await db.select({ appointment: appointments, doctor: doctorProfiles, patient: users }).from(appointments).leftJoin(doctorProfiles, eq(appointments.doctorSlug, doctorProfiles.slug)).leftJoin(users, eq(appointments.patientUserId, users.id)).where(eq(appointments.id, appointmentId)).limit(1);
  return row ? { ...normalizedAppointment(row.appointment, row.doctor?.timezone ?? "UTC"), doctor: row.doctor ? publicDoctor(safeDoctor(row.doctor)) : null, patientName: row.patient?.name ?? "Patient", patientUserId: row.patient?.id } : null;
}

export async function listNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(30);
}

export async function markNotificationRead(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, userId), eq(notifications.id, id)));
  return { success: true };
}

export async function adminOverview() {
  const db = await getDb();
  if (!db) return { doctors: [], users: [], appointments: [], specialties: [], cancellationHours: 24 };
  const doctors = await db.select().from(doctorProfiles).orderBy(asc(doctorProfiles.name));
  const accountRows = await db.select({ user: users, patient: patientProfiles, doctor: doctorProfiles }).from(users).leftJoin(patientProfiles, eq(users.id, patientProfiles.userId)).leftJoin(doctorProfiles, eq(users.id, doctorProfiles.userId)).orderBy(desc(users.createdAt));
  const appointmentRows = await db.select({ appointment: appointments, doctor: doctorProfiles, patient: users }).from(appointments).leftJoin(doctorProfiles, eq(appointments.doctorSlug, doctorProfiles.slug)).leftJoin(users, eq(appointments.patientUserId, users.id)).orderBy(desc(appointments.createdAt)).limit(100);
  const specialtyRows = await db.select().from(specialties).orderBy(asc(specialties.name));
  const [setting] = await db.select().from(siteSettings).where(eq(siteSettings.key, "cancellation_hours")).limit(1);
  return { doctors: doctors.map(safeDoctor), users: accountRows.map(row => ({ id: row.user.id, name: row.doctor?.name ?? row.user.name ?? "Account", email: row.user.email, admin: row.user.role === "admin", role: row.user.role === "admin" ? "admin" : row.user.role === "doctor" ? "doctor" : row.user.role === "patient" ? "patient" : "unregistered", active: row.user.role === "doctor" ? row.doctor?.active ?? false : row.user.role === "patient" ? row.patient?.active ?? false : true })), appointments: appointmentRows.map(row => ({ ...normalizedAppointment(row.appointment, row.doctor?.timezone ?? "UTC"), doctorName: row.doctor?.name ?? "Doctor", patientName: row.patient?.name ?? "Patient" })), specialties: specialtyRows, cancellationHours: Number(setting?.value ?? 24) };
}

export async function adminSetDoctor(input: { slug: string; verified?: boolean; active?: boolean; expectedProfileRevision?: number }) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  return db.transaction(async (tx: any) => {
    const [doctor] = await tx.select().from(doctorProfiles).where(eq(doctorProfiles.slug, input.slug)).for("update").limit(1);
    if (!doctor) throw new Error("Doctor profile not found.");
    if (input.verified !== undefined && doctor.profileRevision !== input.expectedProfileRevision) {
      throw new Error("This doctor profile changed after you opened it. Refresh the page and review the current details.");
    }
    await tx.update(doctorProfiles).set({ ...(input.verified === undefined ? {} : { verified: input.verified }), ...(input.active === undefined ? {} : { active: input.active }) }).where(eq(doctorProfiles.slug, input.slug));
    return { success: true };
  });
}

export async function adminSetUserActive(userId: number, active: boolean) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  const [account] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!account) throw new Error("Account not found.");
  if (account.role === "doctor") {
    await db.update(doctorProfiles).set({ active }).where(eq(doctorProfiles.userId, userId));
    return { success: true };
  }
  const [patient] = account.role === "patient" ? await db.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1) : [];
  if (!patient) throw new Error("No patient or doctor profile exists for that account.");
  await db.update(patientProfiles).set({ active }).where(eq(patientProfiles.userId, userId));
  return { success: true };
}

export async function adminSetSpecialty(name: string, active: boolean) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  if (active) await db.insert(specialties).values({ name, active: true }).onDuplicateKeyUpdate({ set: { active: true } });
  else await db.update(specialties).set({ active: false }).where(eq(specialties.name, name));
  return { success: true };
}

export async function adminSetCancellationHours(hours: number) {
  const db = await getDb();
  if (!db) throw new Error("The managed database is not available yet.");
  await db.insert(siteSettings).values({ key: "cancellation_hours", value: String(hours) }).onDuplicateKeyUpdate({ set: { value: String(hours) } });
  return { success: true };
}

export async function doctorSchedule(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const [doctor] = await db.select().from(doctorProfiles).where(eq(doctorProfiles.userId, userId)).limit(1);
  if (!doctor) return [];
  return db.select().from(doctorSchedules).where(eq(doctorSchedules.doctorSlug, doctor.slug)).orderBy(asc(doctorSchedules.weekday));
}
