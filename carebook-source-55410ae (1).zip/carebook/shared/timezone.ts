export interface LocalDateTimeParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

function parseLocalDateTime(value: string): LocalDateTimeParts {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(value);
  if (!match) throw new Error("Use a local date and time in YYYY-MM-DDTHH:mm format.");
  const [, yearText, monthText, dayText, hourText, minuteText] = match;
  const parts = {
    year: Number(yearText),
    month: Number(monthText),
    day: Number(dayText),
    hour: Number(hourText),
    minute: Number(minuteText),
    second: 0,
  };
  const check = new Date(Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute));
  if (
    check.getUTCFullYear() !== parts.year ||
    check.getUTCMonth() + 1 !== parts.month ||
    check.getUTCDate() !== parts.day ||
    parts.hour > 23 ||
    parts.minute > 59
  ) {
    throw new Error("Choose a valid calendar date and time.");
  }
  return parts;
}

function partsAtInstant(instant: Date, timeZone: string): LocalDateTimeParts {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  const entries = formatter.formatToParts(instant);
  const value = (type: Intl.DateTimeFormatPartTypes) => Number(entries.find(part => part.type === type)?.value);
  return {
    year: value("year"),
    month: value("month"),
    day: value("day"),
    hour: value("hour"),
    minute: value("minute"),
    second: value("second"),
  };
}

function wallPartsAsUtc(parts: LocalDateTimeParts): number {
  return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
}

function sameWallMinute(left: LocalDateTimeParts, right: LocalDateTimeParts): boolean {
  return left.year === right.year &&
    left.month === right.month &&
    left.day === right.day &&
    left.hour === right.hour &&
    left.minute === right.minute;
}

/**
 * Convert a clinic-local wall time to an absolute instant. For the repeated hour
 * at the end of daylight saving time, the earlier occurrence is selected. A time
 * inside the skipped spring-forward hour is rejected instead of silently shifted.
 */
export function clinicLocalToUtc(value: string, timeZone: string): Date {
  const target = parseLocalDateTime(value);
  const targetAsUtc = wallPartsAsUtc(target);
  let guess = targetAsUtc;

  // Correct the UTC guess by the difference between its rendered wall time and
  // the requested clinic wall time. Four iterations are sufficient for IANA
  // zones, including historical second-level offsets.
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const observed = partsAtInstant(new Date(guess), timeZone);
    const correction = targetAsUtc - wallPartsAsUtc(observed);
    if (correction === 0) break;
    guess += correction;
  }

  const result = new Date(guess);
  const resolved = partsAtInstant(result, timeZone);
  if (!sameWallMinute(target, resolved)) {
    throw new Error("That clinic-local time does not exist because of a daylight-saving time change.");
  }
  return result;
}

export function clinicLocalToUtcIso(value: string, timeZone: string): string {
  return clinicLocalToUtc(value, timeZone).toISOString();
}

/** Return the local UTC offset in minutes for this exact instant in the clinic zone. */
export function utcOffsetMinutesAt(value: string | Date, timeZone: string): number {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) throw new Error("The appointment time is invalid.");
  const wholeSecond = Math.floor(instant.getTime() / 1000) * 1000;
  return Math.round((wallPartsAsUtc(partsAtInstant(instant, timeZone)) - wholeSecond) / 60_000);
}

export function utcToClinicLocal(value: string | Date, timeZone: string): string {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) throw new Error("The appointment time is invalid.");
  const parts = partsAtInstant(instant, timeZone);
  return `${String(parts.year).padStart(4, "0")}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}T${String(parts.hour).padStart(2, "0")}:${String(parts.minute).padStart(2, "0")}`;
}

export function clinicDateInputValue(dayOffset: number, timeZone: string, now: Date = new Date()): string {
  if (!Number.isInteger(dayOffset)) throw new Error("Calendar day offset must be a whole number.");
  const today = partsAtInstant(now, timeZone);
  const shifted = new Date(Date.UTC(today.year, today.month - 1, today.day + dayOffset));
  return shifted.toISOString().slice(0, 10);
}

export function addUtcMinutes(value: string | Date, minutes: number): Date {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) throw new Error("The appointment time is invalid.");
  return new Date(instant.getTime() + minutes * 60_000);
}

export function formatClinicDate(value: string | Date, timeZone: string): string {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) return "Date unavailable";
  return new Intl.DateTimeFormat("en-US", { timeZone, month: "short", day: "numeric" }).format(instant);
}

export function formatClinicTime(value: string | Date, timeZone: string): string {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) return "Time unavailable";
  return new Intl.DateTimeFormat("en-US", { timeZone, hour: "numeric", minute: "2-digit", timeZoneName: "short" }).format(instant);
}

export function formatClinicSlot(value: string | Date, timeZone: string): string {
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) return "Appointment time unavailable";
  return new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short",
  }).format(instant);
}
