export type AppRole = "patient" | "doctor" | "admin";
export type ConsultationMode = "in_person" | "online";
export type AppointmentStatus = "pending" | "approved" | "rejected" | "cancelled";

/** Backend/dashboard projection. Never serialize its review fields from public endpoints. */
export interface DoctorSummary {
  slug: string;
  name: string;
  specialty: string;
  qualifications: string;
  experienceYears: number;
  languages: string[];
  clinicName: string;
  location: string;
  consultationTypes: ConsultationMode[];
  fee: number;
  bio: string | null;
  timezone: string;
  verified: boolean;
  active: boolean;
  isSample: boolean;
  profileRevision: number;
}

/** Whitelisted doctor details suitable for unauthenticated search and profiles. */
export type PublicDoctorSummary = Omit<DoctorSummary, "verified" | "active" | "profileRevision">;

export interface AppointmentSummary {
  id: string;
  doctorSlug: string;
  slotStart: string;
  slotEnd: string;
  slotStartUtc: string;
  slotEndUtc: string;
  slotStartOffsetMinutes: number;
  slotEndOffsetMinutes: number;
  timeZone: string;
  mode: ConsultationMode;
  status: AppointmentStatus;
  reason: string | null;
  decisionMessage: string | null;
}
